-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2025 at 10:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accounting_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_balance`
--

CREATE TABLE `account_balance` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `last_updated` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_info`
--

CREATE TABLE `business_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `business_currency` varchar(10) NOT NULL,
  `company_country` varchar(100) NOT NULL,
  `business_email` varchar(255) DEFAULT NULL,
  `business_start_date` date DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dashboard_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `business_info`
--

INSERT INTO `business_info` (`id`, `user_id`, `company_name`, `business_currency`, `company_country`, `business_email`, `business_start_date`, `contact_number`, `address`, `created_at`, `updated_at`, `dashboard_file`) VALUES
(8, 4, 'Sulasok', 'PHP', 'Philippines', NULL, NULL, NULL, NULL, '2025-08-10 11:24:04', '2025-08-10 11:24:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cashflow`
--

CREATE TABLE `cashflow` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `type` enum('inflow','outflow') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `tax_number` varchar(255) DEFAULT NULL,
  `financial_year_start` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `business_currency` varchar(10) NOT NULL DEFAULT 'PHP',
  `company_country` varchar(100) NOT NULL DEFAULT 'Philippines'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `user_id`, `tax_number`, `financial_year_start`, `address`, `country`, `company_name`, `created_at`, `updated_at`, `business_currency`, `company_country`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 'longwee', '2025-08-09 04:26:06', '2025-08-09 04:26:06', 'PHP', 'Philippines'),
(29, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:05:15', '2025-08-12 02:05:15', 'PHP', 'Philippines'),
(31, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:07:28', '2025-08-12 02:07:28', 'PHP', 'Philippines'),
(32, 3, NULL, NULL, NULL, NULL, 'benji labas utong', '2025-08-12 02:22:35', '2025-08-12 02:22:35', 'PHP', 'Belize'),
(33, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:22:41', '2025-08-12 02:22:41', 'PHP', 'Philippines'),
(34, 3, NULL, NULL, NULL, NULL, 'bayabas', '2025-08-12 03:16:46', '2025-08-12 03:16:46', 'PHP', 'Benin'),
(35, 3, '9999999999', '2025-07-30', 'asd', 'Belarus', '', '2025-08-12 03:16:55', '2025-08-12 03:16:55', 'PHP', 'Philippines'),
(36, 5, NULL, NULL, NULL, NULL, 'naruto', '2025-08-12 12:39:56', '2025-08-12 12:39:56', 'PHP', 'Philippines'),
(37, 5, '123', '2025-08-06', 'bucandfala', 'Philippines', '', '2025-08-12 12:40:24', '2025-08-12 12:40:24', 'PHP', 'Philippines'),
(38, 3, NULL, NULL, NULL, NULL, 'trial', '2025-08-12 16:34:17', '2025-08-12 16:34:17', 'PHP', 'Belize'),
(39, 3, '123', '0000-00-00', '', '', '', '2025-08-12 16:34:24', '2025-08-12 16:34:24', 'PHP', 'Philippines');

-- --------------------------------------------------------

--
-- Table structure for table `company_profiles`
--

CREATE TABLE `company_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_do` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `business_length` varchar(255) NOT NULL,
  `team_size` varchar(255) NOT NULL,
  `billing` varchar(255) NOT NULL,
  `akaunting` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_profiles`
--

INSERT INTO `company_profiles` (`id`, `company_id`, `company_do`, `role`, `business_length`, `team_size`, `billing`, `akaunting`, `created_at`, `updated_at`) VALUES
(12, 29, '', '', '', '', '', '[]', '2025-08-12 02:05:16', '2025-08-12 02:05:16'),
(13, 31, '', '', '', '', '', '[]', '2025-08-12 02:07:29', '2025-08-12 02:07:29'),
(14, 33, '', '', '', '', '', '[]', '2025-08-12 02:22:42', '2025-08-12 02:22:42'),
(15, 35, '', 'CEO/CFO/COO', '', '', '', '[]', '2025-08-12 03:16:57', '2025-08-12 03:16:57'),
(16, 37, 'Agriculture', 'Accountant/Bookkeeper', '', '2 to 4', 'Another accounting software', '[\"Manage your inventory\",\"Organize your expenses\"]', '2025-08-12 12:41:08', '2025-08-12 12:41:08'),
(17, 39, '', '', '', '', '', '[]', '2025-08-12 16:40:10', '2025-08-12 16:40:10');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `currency_name` varchar(50) NOT NULL,
  `exchange_rate` decimal(15,6) NOT NULL DEFAULT 1.000000,
  `last_updated` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses_by_category`
--

CREATE TABLE `expenses_by_category` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `expense_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token`, `expires_at`, `created_at`) VALUES
(2, 1, 'f3e9f32bc2c31afd1b8fbc3a97cfe359f78c97abfc691d1c6dfca22ad9e2f911', '2025-08-08 22:34:29', '2025-08-08 19:34:29'),
(4, 4, 'f0cbdbb9d6228c63cdc8c6a6fda7e20eeb9bf75ee8e4accc4c38be3241709c83', '2025-08-10 14:21:54', '2025-08-10 11:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `payables`
--

CREATE TABLE `payables` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount_due` decimal(15,2) NOT NULL DEFAULT 0.00,
  `due_date` date DEFAULT NULL,
  `status` enum('unpaid','paid','overdue') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payables`
--

INSERT INTO `payables` (`id`, `company_id`, `description`, `amount_due`, `due_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 34, 'Office Supplies Invoice', 1500.00, '2025-09-30', 'unpaid', '2025-08-12 19:18:06', '2025-08-12 19:18:06'),
(2, 34, 'Internet Service Bill', 2500.00, '2025-09-15', 'unpaid', '2025-08-12 19:18:06', '2025-08-12 19:18:06'),
(3, 34, 'Electricity Bill', 3500.00, '2025-09-10', 'overdue', '2025-08-12 19:18:06', '2025-08-12 19:18:06'),
(4, 34, 'Printer Maintenance', 1200.00, '2025-08-30', 'paid', '2025-08-12 19:18:06', '2025-08-12 19:18:06');

-- --------------------------------------------------------

--
-- Table structure for table `profit_loss`
--

CREATE TABLE `profit_loss` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `total_revenue` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_expenses` decimal(15,2) NOT NULL DEFAULT 0.00,
  `net_profit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receivables`
--

CREATE TABLE `receivables` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount_due` decimal(15,2) NOT NULL DEFAULT 0.00,
  `due_date` date DEFAULT NULL,
  `status` enum('unpaid','paid','overdue') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'PUTO', 'enjiqt@gmail.com', '$2y$10$zXyawCv.m3Yt/bday7tkuOg.iN3fLzsTI9CCbabgOymuc7g9qcZ3e', '2025-08-08 15:37:40', '2025-08-08 19:44:00'),
(2, 'KUTSINTA', 'ariana@gmail.com', '$2y$10$Azz82c8UkuwVuitZCY5WKeF33JjeUc7Qc3nh1s8V0.T9sYFDRKxiq', '2025-08-08 17:39:24', '2025-08-08 17:39:24'),
(3, 'Geero Andrei', 'jhonmichaelsabado123@gmail.com', '$2y$10$quzi9.A/D6tHDXuJxj6kPuGzHNnNEtuuESyZRxGsiOltAr1XCcnt2', '2025-08-09 04:32:19', '2025-08-09 04:32:19'),
(4, 'Aldrich Mico Felizardo', 'aldrichmico.29@gmail.com', '$2y$10$BrvarIvqq4TuT1CiqKM3tOFB69ytmWhnLmI90s27KSolw8LgZhD.2', '2025-08-10 11:21:21', '2025-08-10 11:21:21'),
(5, 'gerald', 'geraldcuario09@gmail.com', '$2y$10$vW6kYuKqtugGGQHRMgqiee2GklAgMVXshR3mqfmgC0b5TB/TVcste', '2025-08-12 12:39:03', '2025-08-12 12:39:03');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `widget_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `width` int(11) NOT NULL DEFAULT 12,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`widget_id`, `company_id`, `name`, `type`, `width`, `created_at`, `updated_at`) VALUES
(22, 34, 'bayabas recieve', 'receivables', 12, '2025-08-12 19:00:25', '2025-08-12 19:00:25'),
(23, 32, 'benji labas utong recievables', 'receivables', 12, '2025-08-12 19:00:40', '2025-08-12 19:00:40'),
(25, 34, 'bayabas payables 2', 'payables', 12, '2025-08-12 19:15:05', '2025-08-12 19:15:05'),
(26, 34, 'payablesssss', 'payables', 12, '2025-08-12 19:18:41', '2025-08-12 19:18:41'),
(27, 39, 'asda', 'receivables', 12, '2025-08-12 19:50:12', '2025-08-12 19:50:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_balance`
--
ALTER TABLE `account_balance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_info`
--
ALTER TABLE `business_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cashflow`
--
ALTER TABLE `cashflow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_id` (`company_id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `expenses_by_category`
--
ALTER TABLE `expenses_by_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payables`
--
ALTER TABLE `payables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `profit_loss`
--
ALTER TABLE `profit_loss`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `receivables`
--
ALTER TABLE `receivables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`widget_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_balance`
--
ALTER TABLE `account_balance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_info`
--
ALTER TABLE `business_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `cashflow`
--
ALTER TABLE `cashflow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `company_profiles`
--
ALTER TABLE `company_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses_by_category`
--
ALTER TABLE `expenses_by_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payables`
--
ALTER TABLE `payables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `profit_loss`
--
ALTER TABLE `profit_loss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receivables`
--
ALTER TABLE `receivables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `widget_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `business_info`
--
ALTER TABLE `business_info`
  ADD CONSTRAINT `business_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD CONSTRAINT `company_profiles_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
