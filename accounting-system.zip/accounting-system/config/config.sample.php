<?php
// Copy this file to config.php and fill values.
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'gcam_system',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4'
    ],
    'smtp' => [
        'host' => 'smtp.example.com',
        'user' => 'user@example.com',
        'pass' => 'your_smtp_password',
        'port' => 587,
        'from' => 'no-reply@local.test',
        'from_name' => 'Accounting System'
    ],
    'twilio' => [
        'sid' => '',
        'token' => '',
        'from' => ''
    ],
    'site' => [
        'base_url' => 'http://localhost/accounting-system/public'
    ]
];
