<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'accounting_db', // the name of the DB you imported
        'user' => 'root',              // default XAMPP MySQL username
        'pass' => '',                  // default XAMPP MySQL password is empty
        'charset' => 'utf8mb4',
    ]
];

