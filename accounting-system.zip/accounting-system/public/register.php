<?php
// public/register.php
session_start();
require __DIR__ . '/../config/db.php';
$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $full = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $phone = $_POST['phone'] ?? null;
    if(!$full || !$email || !$password){
        $message = 'Please fill required fields.';
    } else {
        // check exists
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        if($stmt->fetch()){
            $message = 'Email already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $ins = $pdo->prepare('INSERT INTO users (full_name,email,password,phone,role) VALUES (?,?,?,?,?)');
            $ins->execute([$full,$email,$hash,$phone,'User']);
            $_SESSION['user'] = ['id'=>$pdo->lastInsertId(),'full_name'=>$full,'email'=>$email,'role'=>'User'];
            header('Location: dashboard.php'); exit;
        }
    }
}
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <h3>Register</h3>
    <?php if($message): ?><div class="alert alert-danger"><?php echo htmlspecialchars($message);?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input class="form-control" type="text" name="full_name" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input class="form-control" type="email" name="email" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Phone (E.164, e.g. +639171234567)</label>
        <input class="form-control" type="text" name="phone">
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input class="form-control" type="password" name="password" required>
      </div>
      <button class="btn btn-primary">Register</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
