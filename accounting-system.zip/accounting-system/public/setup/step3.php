<?php
session_start();
require_once __DIR__ . '/../../config/db.php'; // Ensure $mysqli is defined here

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$userId = $_SESSION['user']['id'];
$username = $_SESSION['user']['name'];

// Get companyId either from session or GET param
$companyId = $_SESSION['current_company_id'] ?? (isset($_GET['company_id']) ? intval($_GET['company_id']) : 0);

if (!$companyId) {
    die("Company ID missing. Please start setup again.");
}

// Verify ownership and get company_name from companies table
$stmt = $mysqli->prepare("SELECT company_name FROM companies WHERE id = ? AND user_id = ?");
if (!$stmt) {
    die("Prepare failed: " . $mysqli->error);
}
$stmt->bind_param("ii", $companyId, $userId);
$stmt->execute();
$stmt->bind_result($companyName);
if (!$stmt->fetch()) {
    $stmt->close();
    die("Company not found or access denied.");
}
$stmt->close();

// Save to session for later use
$_SESSION['current_company_id'] = $companyId;
$_SESSION['company_name'] = $companyName;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finish'])) {
    // Double-check ownership before update/insert
    $stmt = $mysqli->prepare("SELECT id FROM business_info WHERE id = ? AND user_id = ?");
    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }
    $stmt->bind_param("ii", $companyId, $userId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();

        // You can update business_info here if needed (commented out)
        /*
        $newCompanyName = $_POST['company_name'] ?? $companyName;
        $stmt = $mysqli->prepare("UPDATE business_info SET company_name = ? WHERE id = ? AND user_id = ?");
        if (!$stmt) {
            die("Prepare failed: " . $mysqli->error);
        }
        $stmt->bind_param("sii", $newCompanyName, $companyId, $userId);
        $stmt->execute();
        $stmt->close();
        $_SESSION['company_name'] = $newCompanyName;
        */
    } else {
        $stmt->close();

        // Insert logic here if needed (usually unnecessary at this step)
        /*
        $stmt = $mysqli->prepare("INSERT INTO business_info (user_id, company_name) VALUES (?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $mysqli->error);
        }
        $stmt->bind_param("is", $userId, $companyName);
        $stmt->execute();

        $newCompanyId = $mysqli->insert_id;
        $_SESSION['current_company_id'] = $newCompanyId;
        $_SESSION['company_name'] = $companyName;
        $companyId = $newCompanyId;
        $stmt->close();
        */
    }

    // Redirect to the correct company dashboard path with company_id param
    header("Location: ../company/company_dashboard.php?company_id=" . urlencode($companyId));
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Setup Step 3 | CCAM</title>
<style>
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: #f9fafb;
    margin: 0; padding: 0;
    color: #333;
  }
  .container {
    max-width: 600px;
    margin: 100px auto;
    background: white;
    padding: 40px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
  }
  h1 {
    color: #2a5dff;
    margin-bottom: 30px;
  }
  button {
    background: #2a5dff;
    color: white;
    padding: 14px 40px;
    font-weight: 700;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 18px;
  }
  button:hover {
    background: #2248cc;
  }
  .step-indicator {
    margin-bottom: 20px;
    font-weight: 600;
    color: #3a64ff;
  }
</style>
</head>
<body>
<div class="container">
  <div class="step-indicator" aria-live="polite">
    Company &gt; Profile &gt; <strong>Ready</strong>
  </div>

  <h1>You're almost done!</h1>

  <form method="POST" action="">
    <button type="submit" name="finish" aria-label="Finish setup and go to dashboard">Finish Setup</button>
  </form>
</div>
</body>
</html>
