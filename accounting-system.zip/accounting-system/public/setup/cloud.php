<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.php');  // Redirect to login page
    exit;
}

$userId = $_SESSION['user']['id'] ?? null;
if (!$userId) {
    header('Location: login.php');
    exit;
}

require_once realpath(__DIR__ . '/../../config/db.php');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $companyName = trim($_POST['company_name'] ?? '');
    $currency = $_POST['currency'] ?? '';
    $country = $_POST['country'] ?? '';

    // Validation
    if (!$companyName) $errors[] = "Company Name is required.";
    if (!$currency) $errors[] = "Business Currency is required.";
    if (!$country) $errors[] = "Company Location is required.";

    if (empty($errors)) {
        $stmt = $mysqli->prepare("INSERT INTO companies (user_id, company_name, business_currency, company_country) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("isss", $userId, $companyName, $currency, $country);
            if ($stmt->execute()) {
                $companyId = $mysqli->insert_id;

                // Save company info in session for next steps
                $_SESSION['company_id'] = $companyId;
                $_SESSION['company_name'] = $companyName;
                $_SESSION['company_currency'] = $currency;
                $_SESSION['company_country'] = $country;

                $stmt->close();

                // Redirect to next step
                header('Location: loading.php');
                exit;
            } else {
                $errors[] = "Failed to save company information. Please try again.";
            }
            $stmt->close();
        } else {
            $errors[] = "Database error: failed to prepare statement.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Create Company | CCAM</title>
<style>
  /* Basic reset */
  * {
    box-sizing: border-box;
  }
  body, html {
    margin: 0; padding: 0; height: 100%;
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: #f9fafb;
    color: #333;
  }
  .container {
    display: flex;
    height: 100vh;
  }
  .left-half, .right-half {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 40px;
  }
  .left-half {
    background: #2a5dff;
    color: white;
    text-align: center;
    align-items: center;
  }
  .left-half img {
    max-width: 250px;
    margin-bottom: 30px;
  }
  .left-half h1 {
    font-size: 4rem;
    font-weight: 900;
    margin: 0 0 15px 0;
  }
  .left-half p {
    font-size: 1.8rem;
    margin: 0;
  }

  .right-half {
    background: white;
    align-items: center;
  }
  .right-half .logo {
    font-size: 64px;
    font-weight: 900;
    color: #2a5dff;
    margin-bottom: 40px;
    user-select: none;
  }

  form {
    width: 100%;
    max-width: 400px;
  }
  label {
    display: block;
    font-weight: 700;
    margin-bottom: 8px;
    color: #2a5dff;
  }
  input[type="text"], select {
    width: 100%;
    padding: 12px 14px;
    font-size: 18px;
    border: 2px solid #2a5dff;
    border-radius: 8px;
    margin-bottom: 25px;
    appearance: none;
    background: white url('data:image/svg+xml;utf8,<svg fill="%232a5dff" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>') no-repeat right 14px center;
    background-size: 16px 16px;
    cursor: pointer;
  }
  input[type="text"] {
    background-image: none;
    cursor: text;
  }
  select:focus, input[type="text"]:focus {
    outline: none;
    border-color: #2248cc;
    box-shadow: 0 0 8px rgba(34, 72, 204, 0.5);
  }
  button {
    width: 100%;
    background: #2a5dff;
    color: white;
    font-size: 20px;
    font-weight: 700;
    padding: 14px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background: #2248cc;
  }
  .error-list {
    margin-bottom: 20px;
    color: #cc2222;
    font-weight: 700;
  }

  @media (max-width: 768px) {
    .container {
      flex-direction: column;
    }
    .left-half, .right-half {
      flex: none;
      height: 50vh;
      padding: 20px;
    }
    .left-half h1 {
      font-size: 3rem;
    }
    .left-half p {
      font-size: 1.3rem;
    }
    .right-half .logo {
      font-size: 48px;
      margin-bottom: 30px;
    }
  }
</style>
</head>
<body>

<div class="container">
  <div class="left-half" role="complementary">
    <img src="https://cdn-icons-png.flaticon.com/512/190/190411.png" alt="Success Icon" />
    <h1>Great!</h1>
    <p>Let's now create your first company!</p>
  </div>

  <div class="right-half" role="main">
    <div class="logo" aria-label="CCAM logo">CCAM</div>

    <?php if (!empty($errors)): ?>
      <div class="error-list" role="alert" aria-live="assertive">
        <ul>
          <?php foreach ($errors as $err): ?>
            <li><?= htmlspecialchars($err) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <label for="company_name">Company Name<span aria-hidden="true" style="color:#cc2222;"> *</span></label>
      <input type="text" id="company_name" name="company_name" required value="<?= htmlspecialchars($_POST['company_name'] ?? '') ?>" />

      <label for="currency">Business Currency<span aria-hidden="true" style="color:#cc2222;"> *</span></label>
      <select id="currency" name="currency" required aria-describedby="currencyHelp">
        <option value="" disabled <?= !isset($_POST['currency']) ? 'selected' : '' ?>>Select currency</option>
        <?php
        $currencies = ['USD', 'PHP', 'AED', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'CNY', 'INR', 'SGD'];
        foreach ($currencies as $cur) {
            $selected = (isset($_POST['currency']) && $_POST['currency'] === $cur) ? 'selected' : '';
            echo "<option value=\"$cur\" $selected>$cur</option>";
        }
        ?>
      </select>

      <label for="country">Where is your company based?<span aria-hidden="true" style="color:#cc2222;"> *</span></label>
      <select id="country" name="country" required aria-describedby="countryHelp">
        <option value="" disabled <?= !isset($_POST['country']) ? 'selected' : '' ?>>Select country</option>
        <?php
        $countries = [
          "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria",
          "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin",
          "Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso",
          "Burundi","Cambodia","Cameroon","Canada","Cape Verde","Central African Republic","Chad","Chile",
          "China","Colombia","Comoros","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Denmark",
          "Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Estonia","Eswatini",
          "Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada",
          "Guatemala","Guinea","Guyana","Haiti","Honduras","Hungary","Iceland","India","Indonesia","Iran","Iraq",
          "Ireland","Israel","Italy","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","Kuwait",
          "Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania",
          "Luxembourg","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania",
          "Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique",
          "Myanmar","Namibia","Nauru","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","North Korea",
          "North Macedonia","Norway","Oman","Pakistan","Palau","Palestine","Panama","Papua New Guinea","Paraguay",
          "Peru","Philippines","Poland","Portugal","Qatar","Romania","Russia","Rwanda","Saint Kitts and Nevis",
          "Saint Lucia","Saint Vincent and the Grenadines","Samoa","San Marino","Saudi Arabia","Senegal","Serbia",
          "Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa",
          "South Korea","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria","Taiwan",
          "Tajikistan","Tanzania","Thailand","Togo","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan",
          "Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan",
          "Vanuatu","Vatican City","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
        ];
        foreach ($countries as $countryName) {
            $selected = (isset($_POST['country']) && $_POST['country'] === $countryName) ? 'selected' : '';
            echo "<option value=\"$countryName\" $selected>$countryName</option>";
        }
        ?>
      </select>

      <button type="submit">Create Company</button>
    </form>
  </div>
</div>

</body>
</html>
