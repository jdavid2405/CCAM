<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$rootPath = realpath(__DIR__ . '/../../');
require_once $rootPath . '/config/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user']['id'] ?? null;
$companyId = $_SESSION['company_id'] ?? null;

if (!$companyId) {
    // No company in session, send back to start
    header('Location: cloud.php');
    exit;
}

// Verify company belongs to this user for security
$stmt = $mysqli->prepare("SELECT company_name FROM companies WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $companyId, $userId);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    // Company not found or doesn't belong to user
    $stmt->close();
    // Clear session company info to force restart
    unset($_SESSION['company_id'], $_SESSION['company_name']);
    header('Location: cloud.php');
    exit;
}

$stmt->bind_result($companyName);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Loading | CCAM</title>
<meta http-equiv="refresh" content="3;url=step1.php" />
<style>
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: #f9fafb;
    color: #333;
    display: flex;
    height: 100vh;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  h1 {
    color: #2a5dff;
    font-size: 2.5rem;
  }
  p {
    font-size: 1.2rem;
    margin-top: 10px;
  }
  .loader {
    margin-top: 20px;
    border: 6px solid #f3f3f3;
    border-top: 6px solid #2a5dff;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    animation: spin 1s linear infinite;
  }
  @keyframes spin {
    0% { transform: rotate(0deg);}
    100% { transform: rotate(360deg);}
  }
</style>
</head>
<body>
<h1>Please take a rest</h1>
<p>We will now start creating your company...</p>
<div class="loader" aria-label="Loading animation"></div>
</body>
</html>
