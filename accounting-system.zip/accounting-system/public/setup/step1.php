<?php
session_start();

$rootPath = realpath(__DIR__ . '/../../');
require_once $rootPath . '/config/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$userId = $_SESSION['user']['id'];

// Handle Skip button - if pressed, redirect to next step without saving
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['skip'])) {
    header('Location: step2.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    // Collect and sanitize inputs
    $tax_number = $_POST['tax_number'] ?? '';
    $financial_year_start = $_POST['financial_year_start'] ?? '';
    $address = $_POST['address'] ?? '';
    $country = $_POST['country'] ?? '';

    // TODO: Add validation as needed (required fields, formats, etc.)

    // Prepare insert statement
    $stmt = $mysqli->prepare("INSERT INTO companies (user_id, tax_number, financial_year_start, address, country) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }

    // IMPORTANT: bind_param requires variables passed by reference
    $stmt->bind_param("issss", $userId, $tax_number, $financial_year_start, $address, $country);

    if ($stmt->execute()) {
        $newCompanyId = $stmt->insert_id;
        $_SESSION['company_id'] = $newCompanyId;
        $stmt->close();

        // Redirect to step2.php with company_id param
        header('Location: step2.php?company_id=' . $newCompanyId);
        exit;
    } else {
        die("Database error: " . $stmt->error);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Setup Step 1 | CCAM</title>
<style>
  /* Base Reset */
  * {
    box-sizing: border-box;
  }
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
    margin: 0; 
    padding: 0;
    color: #1a1a1a;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
  .container {
    max-width: 680px;
    margin: 60px auto 80px;
    background: #ffffff;
    padding: 40px 48px 48px;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.12);
    border: 1px solid #e1e4eb;
  }
  .step-indicator {
    font-weight: 600;
    color: #3a64ff;
    font-size: 1rem;
    margin-bottom: 28px;
    user-select: none;
  }
  h1 {
    font-weight: 700;
    font-size: 2.4rem;
    color: #2a3a72;
    margin-bottom: 32px;
    letter-spacing: 0.02em;
  }
  label {
    display: block;
    font-weight: 600;
    font-size: 1rem;
    margin-bottom: 8px;
    color: #33475b;
    user-select: none;
  }
  input[type="text"],
  input[type="date"],
  select {
    width: 100%;
    padding: 14px 18px;
    margin-bottom: 28px;
    border: 1.8px solid #3a64ff;
    border-radius: 8px;
    font-size: 1.05rem;
    color: #1a1a1a;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    outline-offset: 2px;
  }
  input[type="text"]:focus,
  input[type="date"]:focus,
  select:focus {
    border-color: #2a3a72;
    box-shadow: 0 0 8px rgba(42, 58, 114, 0.3);
  }
  .flex-row {
    display: flex;
    gap: 30px;
    margin-bottom: 20px;
  }
  .flex-item {
    flex: 1;
  }
  /* File drop zone */
  .file-drop {
    border: 2.2px dashed #3a64ff;
    border-radius: 10px;
    padding: 35px 20px;
    text-align: center;
    color: #3a64ff;
    font-weight: 600;
    font-size: 1.1rem;
    user-select: none;
    transition: background-color 0.25s ease, border-color 0.25s ease, color 0.25s ease;
    cursor: pointer;
    margin-bottom: 34px;
    position: relative;
  }
  .file-drop:hover,
  .file-drop:focus {
    background-color: #f0f4ff;
    border-color: #2a3a72;
    color: #2a3a72;
    outline: none;
  }
  .file-drop:focus {
    box-shadow: 0 0 12px rgba(42, 58, 114, 0.4);
  }
  .file-drop input[type="file"] {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0; left: 0;
    opacity: 0;
    cursor: pointer;
  }
  /* Buttons container */
  .button-group {
    display: flex;
    justify-content: space-between;
    gap: 18px;
  }
  button {
    background: #3a64ff;
    border: none;
    border-radius: 10px;
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 14px 34px;
    cursor: pointer;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    user-select: none;
  }
  button[name="skip"] {
    background: transparent;
    color: #6b7c93;
    border: 2px solid #6b7c93;
  }
  button[name="skip"]:hover {
    color: #3a64ff;
    border-color: #3a64ff;
    background-color: #f0f4ff;
  }
  button[name="save"]:hover {
    background-color: #2a3a72;
    box-shadow: 0 0 16px rgba(42, 58, 114, 0.4);
  }
  /* Responsive */
  @media (max-width: 520px) {
    .flex-row {
      flex-direction: column;
      gap: 18px;
    }
    .container {
      padding: 32px 24px 36px;
      margin: 40px 16px 60px;
    }
    h1 {
      font-size: 1.9rem;
    }
  }
</style>
</style>
</head>
<body>
<div class="container" role="main" aria-label="Company setup step 1">
  <div class="step-indicator" aria-live="polite">
    <span>Company</span> &gt; Profile &gt; Ready
  </div>
  <h1>Company Details</h1>

  <form method="POST" enctype="multipart/form-data" action="" novalidate>

    <div class="flex-row">
      <div class="flex-item">
        <label for="tax_number">Tax Number</label>
        <input type="text" id="tax_number" name="tax_number" placeholder="Enter tax number" required />
      </div>
      <div class="flex-item">
        <label for="financial_year_start">Financial Year Start</label>
        <input type="date" id="financial_year_start" name="financial_year_start" required />
      </div>
    </div>

    <label for="address">Address</label>
    <input type="text" id="address" name="address" placeholder="Enter company address" required />

    <label for="country">Country</label>
    <select id="country" name="country" required aria-required="true">
      <option value="" disabled selected>Select a country</option>
      <?php
        $countries = [
          "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria",
          "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin",
          "Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso",
          "Burundi","Cambodia","Cameroon","Canada","Cape Verde","Central African Republic","Chad","Chile",
          "China","Colombia","Comoros","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Denmark",
          "Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Estonia","Eswatini",
          "Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada",
          "Guatemala","Guinea","Guyana","Haiti","Honduras","Hungary","Iceland","India","Indonesia","Iran","Iraq",
          "Ireland","Israel","Italy","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","Kuwait",
          "Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania",
          "Luxembourg","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania",
          "Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique",
          "Myanmar","Namibia","Nauru","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","North Korea",
          "North Macedonia","Norway","Oman","Pakistan","Palau","Palestine","Panama","Papua New Guinea","Paraguay",
          "Peru","Philippines","Poland","Portugal","Qatar","Romania","Russia","Rwanda","Saint Kitts and Nevis",
          "Saint Lucia","Saint Vincent and the Grenadines","Samoa","San Marino","Saudi Arabia","Senegal","Serbia",
          "Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa",
          "South Korea","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria","Taiwan",
          "Tajikistan","Tanzania","Thailand","Togo","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan",
          "Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan",
          "Vanuatu","Vatican City","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
        ];
        foreach ($countries as $country) {
          echo '<option value="' . htmlspecialchars($country) . '">' . htmlspecialchars($country) . '</option>';
        }
      ?>
    </select>

    <div class="file-drop" id="fileDrop" tabindex="0" aria-label="Drop a file here or click to upload">
      Drag and drop a file here or click to upload
      <input type="file" id="fileInput" name="fileInput" aria-hidden="true" />
    </div>

    <div class="button-group">
      <button type="submit" name="skip" value="skip">Skip this step</button>
      <button type="submit" name="save" value="save">Save</button>
    </div>
  </form>
</div>

<script>
  const fileDrop = document.getElementById('fileDrop');
  const fileInput = document.getElementById('fileInput');

  fileDrop.addEventListener('click', () => fileInput.click());

  fileDrop.addEventListener('dragover', e => {
    e.preventDefault();
    fileDrop.style.backgroundColor = '#e3eaff';
    fileDrop.style.borderColor = '#2a3a72';
    fileDrop.style.color = '#2a3a72';
  });

  fileDrop.addEventListener('dragleave', e => {
    e.preventDefault();
    fileDrop.style.backgroundColor = 'transparent';
    fileDrop.style.borderColor = '#3a64ff';
    fileDrop.style.color = '#3a64ff';
  });

  fileDrop.addEventListener('drop', e => {
    e.preventDefault();
    fileDrop.style.backgroundColor = 'transparent';
    fileDrop.style.borderColor = '#3a64ff';
    fileDrop.style.color = '#3a64ff';

    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      alert('File selected: ' + e.dataTransfer.files[0].name);
    }
  });
</script>
</body>
</html>