<?php
session_start();

$rootPath = realpath(__DIR__ . '/../../');
require_once $rootPath . '/config/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$userId = $_SESSION['user']['id'];
$companyId = $_GET['company_id'] ?? $_SESSION['current_company_id'] ?? null;

if (!$companyId) {
    header('Location: ../cloud.php');
    exit;
}

// Verify company belongs to logged-in user
$stmt = $mysqli->prepare("SELECT id, company_name FROM companies WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $companyId, $userId);
$stmt->execute();
$result = $stmt->get_result();
$company = $result->fetch_assoc();
$stmt->close();

if (!$company) {
    die("Error: Company not found or access denied.");
}

// Save current company ID to session for continuity
$_SESSION['current_company_id'] = $companyId;

// Options arrays
$company_do_options = [
    'Agriculture','Art and Design','Construction Trades and Home Services','Development & Programming',
    'Education and Training','Financial Services & Insurance','Food Services','Health and Wellness',
    'Hospitality Travel and Tourism','Human Resources and Staffing','Information Technology',
    'Manufacturing','Non-Profit','Other',
    'Professional Services (e.g. legal, accounting, marketing, consulting)',
    'Real Estate and Property Management','Retail (E-commerce and offline)','Software Development',
    'Wholesale Trade'
];

$role_options = [
    'Accountant/Bookkeeper','CEO/CFO/COO','CTO','Developer/Designer','Director/Administrator',
    'Human Resources','Other','Owner/Founder','Sales/Marketing'
];

$business_length_options = [
    '1-2 years','3-4 years','5-9 years','10-14 years','15+ years','Less than a year'
];

$team_size_options = [
    'Just me','2 to 4','5 to 9','10 to 19','20 to 49','More than 50'
];

$billing_options = [
    'Another accounting software','I don\'t use anything','Pen and paper',
    'Spreadsheets and word documents'
];

$akaunting_options = [
    'Manage your inventory','Organize your expenses','Pay your employees','Send and track invoices',
    'Track your bills','Track your tax'
];

// Helpers
function isSelected($val, $postVal) {
    return ($postVal === $val) ? 'selected' : '';
}
function isChecked($val, $postArray) {
    return (is_array($postArray) && in_array($val, $postArray)) ? 'checked' : '';
}

// Fetch existing profile data if any
$stmt = $mysqli->prepare("SELECT company_do, role, business_length, team_size, billing, akaunting FROM company_profiles WHERE company_id = ?");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$result = $stmt->get_result();
$profile = $result->fetch_assoc();
$stmt->close();

// Decode akaunting JSON to array if exists
if ($profile && !empty($profile['akaunting'])) {
    $profile['akaunting'] = json_decode($profile['akaunting'], true);
} else {
    $profile['akaunting'] = [];
}

// Use POST data if available, else fallback to profile data, else default empty
$post_company_do = $_POST['company_do'] ?? $profile['company_do'] ?? '';
$post_role = $_POST['role'] ?? $profile['role'] ?? '';
$post_business_length = $_POST['business_length'] ?? $profile['business_length'] ?? '';
$post_team_size = $_POST['team_size'] ?? $profile['team_size'] ?? '';
$post_billing = $_POST['billing'] ?? $profile['billing'] ?? '';
$post_akaunting = $_POST['akaunting'] ?? $profile['akaunting'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['previous'])) {
        header('Location: step1.php?company_id=' . urlencode($companyId));
        exit;
    }

    if (isset($_POST['save'])) {
        // Sanitize inputs (you might want to do more validation)
        $company_do = $_POST['company_do'] ?? '';
        $role = $_POST['role'] ?? '';
        $business_length = $_POST['business_length'] ?? '';
        $team_size = $_POST['team_size'] ?? '';
        $billing = $_POST['billing'] ?? '';
        $akaunting = $_POST['akaunting'] ?? [];

        $akaunting_json = json_encode($akaunting);

        // Check if profile exists to decide insert/update
        $stmt = $mysqli->prepare("SELECT id FROM company_profiles WHERE company_id = ?");
        $stmt->bind_param("i", $companyId);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->close();
            $stmt = $mysqli->prepare("UPDATE company_profiles SET company_do = ?, role = ?, business_length = ?, team_size = ?, billing = ?, akaunting = ?, updated_at = NOW() WHERE company_id = ?");
            $stmt->bind_param("ssssssi", $company_do, $role, $business_length, $team_size, $billing, $akaunting_json, $companyId);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt->close();
            $stmt = $mysqli->prepare("INSERT INTO company_profiles (company_id, company_do, role, business_length, team_size, billing, akaunting) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssss", $companyId, $company_do, $role, $business_length, $team_size, $billing, $akaunting_json);
            $stmt->execute();
            $stmt->close();
        }

        header('Location: step3.php?company_id=' . urlencode($companyId));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Setup Step 2 | CCAM</title>
<style>
  /* Base Reset */
  * {
    box-sizing: border-box;
  }
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
    margin: 0; 
    padding: 0;
    color: #1a1a1a;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
  .container {
    max-width: 900px;
    margin: 60px auto 80px;
    background: #ffffff;
    padding: 40px 48px 48px;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.12);
    border: 1px solid #e1e4eb;
  }
  .step-indicator {
    font-weight: 600;
    color: #3a64ff;
    font-size: 1rem;
    margin-bottom: 28px;
    user-select: none;
  }
  h1 {
    font-weight: 700;
    font-size: 2.4rem;
    color: #2a3a72;
    margin-bottom: 32px;
    letter-spacing: 0.02em;
  }
  form {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 28px 40px;
  }
  label {
    display: block;
    font-weight: 600;
    font-size: 1rem;
    margin-bottom: 8px;
    color: #33475b;
    user-select: none;
  }
  select, .multi-select > button {
    width: 100%;
    padding: 14px 18px;
    border: 1.8px solid #3a64ff;
    border-radius: 8px;
    font-size: 1.05rem;
    color: #1a1a1a;
    cursor: pointer;
    background: white;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    outline-offset: 2px;
    appearance: none;
  }
  select:focus, .multi-select > button:focus {
    border-color: #2a3a72;
    box-shadow: 0 0 8px rgba(42, 58, 114, 0.3);
    outline: none;
  }
  /* Dropdown arrow for selects */
  select {
    background-image: url('data:image/svg+xml;utf8,<svg fill="%233a64ff" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
    background-repeat: no-repeat;
    background-position: right 14px center;
    background-size: 16px 16px;
  }
  /* Multi-select */
  .multi-select {
    position: relative;
  }
  .multi-select > button {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .multi-select > button:after {
    content: "⌄";
    font-size: 18px;
    color: #3a64ff;
    margin-left: 6px;
  }
  .options-container {
    position: absolute;
    z-index: 10;
    background: white;
    border: 1.8px solid #3a64ff;
    border-radius: 8px;
    max-height: 180px;
    overflow-y: auto;
    width: 100%;
    margin-top: 5px;
    display: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
  }
  .options-container label {
    display: block;
    padding: 8px 14px;
    cursor: pointer;
    user-select: none;
    color: #1a1a1a;
  }
  .options-container label:hover {
    background-color: #dbe7ff;
  }
  /* Buttons container */
  .buttons-row {
    grid-column: span 2;
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-top: 36px;
  }
  button {
    font-weight: 700;
    font-size: 1.1rem;
    padding: 14px 36px;
    border-radius: 10px;
    cursor: pointer;
    user-select: none;
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    border: none;
    color: white;
  }
  button[name="save"] {
    background-color: #3a64ff;
  }
  button[name="save"]:hover {
    background-color: #2a3a72;
    box-shadow: 0 0 16px rgba(42, 58, 114, 0.4);
  }
  button.previous {
    background: transparent;
    border: 2px solid #6b7c93;
    color: #6b7c93;
  }
  button.previous:hover {
    background-color: #f0f4ff;
    border-color: #3a64ff;
    color: #3a64ff;
  }
  /* Responsive */
  @media (max-width: 720px) {
    form {
      grid-template-columns: 1fr;
      gap: 24px;
    }
    .buttons-row {
      flex-direction: column;
      gap: 14px;
      align-items: stretch;
    }
    button {
      width: 100%;
      padding: 14px;
    }
  }
</style>
</head>
<body>
<div class="container" role="main" aria-label="Profile setup step 2">
  <div class="step-indicator" aria-live="polite">
    Company &gt; <span> Profile</span> &gt;  Ready
  </div>
  <h1>Profile Details for <?= htmlspecialchars($company['company_name']) ?></h1>

  <form method="POST" action="?company_id=<?= urlencode($companyId) ?>" novalidate>

    <!-- 1: What does your company do? -->
    <div>
      <label for="company_do">What does your company do?</label>
      <select id="company_do" name="company_do" required>
        <option value="" disabled <?= empty($post_company_do) ? 'selected' : '' ?>>Choose an option</option>
        <?php foreach ($company_do_options as $opt): ?>
          <option value="<?= htmlspecialchars($opt) ?>" <?= isSelected($opt, $post_company_do) ?>><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- 2: What is your role at the company? -->
    <div>
      <label for="role">What is your role at the company?</label>
      <select id="role" name="role" required>
        <option value="" disabled <?= empty($post_role) ? 'selected' : '' ?>>Choose an option</option>
        <?php foreach ($role_options as $opt): ?>
          <option value="<?= htmlspecialchars($opt) ?>" <?= isSelected($opt, $post_role) ?>><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- 3: How long have you been in the business? -->
    <div>
      <label for="business_length">How long have you been in the business?</label>
      <select id="business_length" name="business_length" required>
        <option value="" disabled <?= empty($post_business_length) ? 'selected' : '' ?>>Choose an option</option>
        <?php foreach ($business_length_options as $opt): ?>
          <option value="<?= htmlspecialchars($opt) ?>" <?= isSelected($opt, $post_business_length) ?>><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- 4: How many team members do you have? -->
    <div>
      <label for="team_size">How many team members do you have?</label>
      <select id="team_size" name="team_size" required>
        <option value="" disabled <?= empty($post_team_size) ? 'selected' : '' ?>>Choose an option</option>
        <?php foreach ($team_size_options as $opt): ?>
          <option value="<?= htmlspecialchars($opt) ?>" <?= isSelected($opt, $post_team_size) ?>><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- 5: What do you use to bill your customers? -->
    <div>
      <label for="billing">What do you use to bill your customers?</label>
      <select id="billing" name="billing" required>
        <option value="" disabled <?= empty($post_billing) ? 'selected' : '' ?>>Choose an option</option>
        <?php foreach ($billing_options as $opt): ?>
          <option value="<?= htmlspecialchars($opt) ?>" <?= isSelected($opt, $post_billing) ?>><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- 6: What would you like to do in akaunting? (multi-select) -->
    <div class="multi-select" style="position:relative;">
      <label for="akaunting">What would you like to do in akaunting?</label>
      <button type="button" id="akauntingToggle" aria-haspopup="listbox" aria-expanded="false" aria-labelledby="akauntingLabel">
        Choose options
      </button>
      <div class="options-container" role="listbox" aria-multiselectable="true" id="akauntingOptions" tabindex="-1">
        <?php foreach ($akaunting_options as $opt): ?>
          <label>
            <input type="checkbox" name="akaunting[]" value="<?= htmlspecialchars($opt) ?>"
              <?= isChecked($opt, $post_akaunting) ?> />
            <?= htmlspecialchars($opt) ?>
          </label>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="buttons-row">
      <button type="submit" name="previous" class="previous">Previous</button>
      <button type="submit" name="save">Save</button>
    </div>
  </form>
</div>

<script>
  const akauntingToggle = document.getElementById('akauntingToggle');
  const akauntingOptions = document.getElementById('akauntingOptions');

  akauntingToggle.addEventListener('click', () => {
    const expanded = akauntingToggle.getAttribute('aria-expanded') === 'true';
    akauntingToggle.setAttribute('aria-expanded', !expanded);
    akauntingOptions.style.display = expanded ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!akauntingToggle.contains(e.target) && !akauntingOptions.contains(e.target)) {
      akauntingOptions.style.display = 'none';
      akauntingToggle.setAttribute('aria-expanded', 'false');
    }
  });

  const checkboxes = akauntingOptions.querySelectorAll('input[type=checkbox]');
  function updateLabel() {
    const checked = Array.from(checkboxes).filter(c => c.checked).map(c => c.value);
    akauntingToggle.textContent = checked.length ? checked.join(', ') + ' ⌄' : 'Choose options ⌄';
  }
  checkboxes.forEach(cb => cb.addEventListener('change', updateLabel));
  updateLabel();
</script>

</body>
</html>
