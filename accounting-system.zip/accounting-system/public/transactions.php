<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: index.php'); exit; }
require __DIR__ . '/../config/db.php';
$user = $_SESSION['user'];
$company_id = null;
$stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$company_id = $stmt->fetchColumn();
if(!$company_id){
    header('Location: companies.php'); exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'])){
    $type = $_POST['type'];
    $date = $_POST['date'] ?: date('Y-m-d');
    $amount = $_POST['amount'];
    $desc = $_POST['description'];
    $cat = $_POST['category'] ?: null;
    $ins = $pdo->prepare('INSERT INTO transactions (company_id,category_id,type,date,description,amount) VALUES (?,?,?,?,?,?)');
    $ins->execute([$company_id,$cat,$type,$date,$desc,$amount]);
    header('Location: transactions.php'); exit;
}
$sth = $pdo->prepare('SELECT t.*, c.name as category_name FROM transactions t LEFT JOIN categories c ON c.id = t.category_id WHERE t.company_id = ? ORDER BY t.date DESC');
$sth->execute([$company_id]);
$tx = $sth->fetchAll();
$cats = $pdo->prepare('SELECT * FROM categories WHERE company_id = ?');
$cats->execute([$company_id]);
$categories = $cats->fetchAll();
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row">
  <div class="col-md-8">
    <h4>Transactions</h4>
    <table class="table table-sm">
      <thead><tr><th>Date</th><th>Type</th><th>Category</th><th>Amount</th><th>Description</th></tr></thead>
      <tbody>
        <?php foreach($tx as $t): ?>
          <tr>
            <td><?php echo htmlspecialchars($t['date']);?></td>
            <td><?php echo htmlspecialchars($t['type']);?></td>
            <td><?php echo htmlspecialchars($t['category_name']);?></td>
            <td><?php echo number_format($t['amount'],2);?></td>
            <td><?php echo htmlspecialchars($t['description']);?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="col-md-4">
    <h5>Add Transaction</h5>
    <form method="post">
      <div class="mb-2"><label>Type</label><select class="form-select" name="type"><option value="income">Income</option><option value="expense">Expense</option></select></div>
      <div class="mb-2"><label>Date</label><input class="form-control" type="date" name="date" value="<?php echo date('Y-m-d');?>"></div>
      <div class="mb-2"><label>Amount</label><input class="form-control" type="number" step="0.01" name="amount" required></div>
      <div class="mb-2"><label>Category</label><select class="form-select" name="category"><option value="">--None--</option><?php foreach($categories as $c){ echo "<option value=\"{$c['id']}\">".htmlspecialchars($c['name'])."</option>";} ?></select></div>
      <div class="mb-2"><label>Description</label><input class="form-control" name="description"></div>
      <button class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
