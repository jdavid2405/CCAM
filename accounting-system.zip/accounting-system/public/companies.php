<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: index.php'); exit; }
require __DIR__ . '/../config/db.php';
$user = $_SESSION['user'];
$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim($_POST['name'] ?? '');
    $language = $_POST['language'] ?? '';
    $currency = $_POST['currency'] ?? '';
    $country = $_POST['country'] ?? '';
    if(!$name || !$language || !$currency){
        $message = 'Please fill required fields.';
    } else {
        $ins = $pdo->prepare('INSERT INTO companies (user_id,name,language,currency,country) VALUES (?,?,?,?,?)');
        $ins->execute([$user['id'],$name,$language,$currency,$country]);
        header('Location: dashboard.php'); exit;
    }
}
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row">
  <div class="col-md-6">
    <h4>Create Company</h4>
    <?php if($message): ?><div class="alert alert-danger"><?php echo htmlspecialchars($message);?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label>Company Name *</label>
        <input class="form-control" name="name" required>
      </div>
      <div class="mb-3">
        <label>Language *</label>
        <select class="form-select" name="language" required>
          <option value="">Choose</option>
          <option>English</option>
          <option>Filipino</option>
        </select>
      </div>
      <div class="mb-3">
        <label>Currency *</label>
        <select class="form-select" name="currency" required>
          <option value="">Choose</option>
          <option>PHP</option>
          <option>USD</option>
        </select>
      </div>
      <div class="mb-3">
        <label>Country</label>
        <input class="form-control" name="country">
      </div>
      <button class="btn btn-primary">Create Company</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
