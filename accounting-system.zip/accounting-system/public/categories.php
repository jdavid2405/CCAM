<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: index.php'); exit; }
require __DIR__ . '/../config/db.php';
$user = $_SESSION['user'];
$company_id = null;
$stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$company_id = $stmt->fetchColumn();
if(!$company_id){
    header('Location: companies.php'); exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])){
    $name = $_POST['name'];
    $type = $_POST['type'];
    $ins = $pdo->prepare('INSERT INTO categories (company_id,name,type) VALUES (?,?,?)');
    $ins->execute([$company_id,$name,$type]);
    header('Location: categories.php'); exit;
}
$sth = $pdo->prepare('SELECT * FROM categories WHERE company_id = ?');
$sth->execute([$company_id]);
$cats = $sth->fetchAll();
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row">
  <div class="col-md-6">
    <h4>Categories</h4>
    <form method="post" class="mb-3">
      <div class="input-group">
        <input class="form-control" name="name" placeholder="Category name" required>
        <select class="form-select" name="type">
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
        <button class="btn btn-primary">Add</button>
      </div>
    </form>
    <table class="table table-sm">
      <thead><tr><th>Name</th><th>Type</th></tr></thead>
      <tbody>
        <?php foreach($cats as $c): ?>
          <tr><td><?php echo htmlspecialchars($c['name']);?></td><td><?php echo htmlspecialchars($c['type']);?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
