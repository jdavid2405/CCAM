<?php
echo "PHP file is working!";
