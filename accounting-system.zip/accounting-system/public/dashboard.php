<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');  // Redirect if no user session
    exit;
}

$rootPath = realpath(__DIR__ . '/../'); // Adjust if needed
require_once $rootPath . '/config/db.php';

$userId = $_SESSION['user']['id'] ?? null;
$username = $_SESSION['user']['name'] ?? '';

$errors = [];
$successMsg = '';

// Handle delete request with error checking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && isset($_POST['delete_company_id'])) {
    $deleteId = intval($_POST['delete_company_id']);

    $stmtDel = $mysqli->prepare("DELETE FROM companies WHERE id = ? AND user_id = ?");
    if ($stmtDel) {
        $stmtDel->bind_param("ii", $deleteId, $userId);
        if (!$stmtDel->execute()) {
            $errors[] = "Delete failed: " . $stmtDel->error;
        } else if ($stmtDel->affected_rows > 0) {
            $successMsg = "Company deleted successfully.";
            // Clear session company_id if it was the deleted one
            if (isset($_SESSION['company_id']) && $_SESSION['company_id'] == $deleteId) {
                unset($_SESSION['company_id']);
            }
        } else {
            $errors[] = "Failed to delete company or company not found.";
        }
        $stmtDel->close();
    } else {
        $errors[] = "Database error while preparing delete.";
    }
}

// Fetch all companies for this user, excluding blank names
$companies = [];
if ($userId) {
    $stmt = $mysqli->prepare("SELECT id, company_name FROM companies WHERE user_id = ? AND TRIM(company_name) != '' ORDER BY id ASC");
    if ($stmt) {
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $companies[] = $row;
        }
        $stmt->close();
    }
}

// Validate company_id selection against existing companies
$validCompanyIds = array_column($companies, 'id');

if (isset($_GET['company_id']) && in_array(intval($_GET['company_id']), $validCompanyIds, true)) {
    $company_id = intval($_GET['company_id']);
    $_SESSION['company_id'] = $company_id;
} elseif (isset($_SESSION['company_id']) && in_array($_SESSION['company_id'], $validCompanyIds, true)) {
    $company_id = $_SESSION['company_id'];
} elseif (count($companies) > 0) {
    $company_id = $companies[0]['id'];
    $_SESSION['company_id'] = $company_id;
} else {
    $company_id = null; // no companies yet
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dashboard | CCAM</title>
<style>
  /* Reset and base */
* {
  box-sizing: border-box;
}
body {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  margin: 0;
  padding: 0;
  background: #f9fafb;
  color: #333;
}
a {
  color: #2a5dff;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}

/* Navbar */
.navbar {
  display: flex;
  align-items: center;
  background-color: #fff;
  padding: 15px 30px;
  box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
}

.navbar .logo {
  margin-right: auto;
  font-weight: 700;
  font-size: 32px;
  color: #2a5dff;
  cursor: pointer;
  margin-left: 443px;
}

.nav-left {
  display: flex;
  gap: 30px;
  margin-right: 540px;
}

.nav-left a {
  font-weight: 600;
  font-size: 16px;
  color: #545557ff;
  text-decoration: none;
}

.nav-left a:hover {
  text-decoration: underline;
}

.nav-right {
  display: flex;
  gap: 15px;
  position: relative;
  left: var(--nav-right-left-offset, 0);
}

.nav-right button {
  font-weight: 600;
  font-size: 16px;
  padding: 8px 18px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease;
}

.get-started-btn {
  background: #2a5dff;
  color: white;
}

.get-started-btn:hover {
  background: #2248cc;
}

/* Page heading */
.page-header {
  max-width: 1000px;
  margin: 50px auto 20px auto;
  padding: 0 20px;
  margin-left: 443px;

  /* Flex container for horizontal alignment */
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.page-header h1 {
  font-size: 4.5rem;
  font-weight: 900;
  margin: 0 0 10px 0;
  color: #111;
}
.page-header p {
  font-size: 1.1rem;
  color: #666;
  margin: 0;
}

#userGreeting {
  position: absolute;
  right: 500px;
  font-weight: 900;
  font-size: 2.5rem;
  color: #2a5dff;
  user-select: none;
  white-space: nowrap;
  margin-left: 30px;
  margin-top: 350px;
}

/* Layout */
.container {
  max-width: 1000px;
  margin: 20px auto 200px auto;
  padding: 0 20px;
  display: flex;
  gap: 50px;
  margin-left: 443px;
  align-items: flex-start;
}

/* Sidebar */
.sidebar {
  max-width: none;
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: none;
  margin-top: 180px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.sidebar button {
  background: none;
  border: none;
  text-align: left;
  font-size: 18px;
  font-weight: 700;
  color: #545557ff;
  padding: 10px 20px;
  border-left: 6px solid transparent;
  cursor: pointer;
  transition: all 0.3s ease;
}

.sidebar button:hover {
  background-color: #e6f0ff;
  color: #2a5dff;
}

.sidebar button.active {
  border-left: 120px solid #2a5dff;
  color: #2a5dff;
  background-color: #dbe7ff;
  box-shadow: 5px 0 0 #2a5dff;
}

/* Main content area */
.main-content {
  flex: 1;
  max-width: 600px;
}

.main-content h2 {
  font-size: 1.8rem;
  font-weight: 700;
  margin-bottom: 10px;
  color: #111;
}

hr {
  border: none;
  border-top: 1px solid #ccc;
  margin: 15px 0 25px 0;
}

/* Company buttons container */
#companyButtons {
    display: grid;
  grid-template-columns: repeat(2, 1fr); /* 2 equal columns */
  gap: 12px 20px; /* row-gap and column-gap */
  margin-bottom: 10px;
  margin-top: 10px;
  justify-content: start; /* align left */
}

/* Company button styling */
.companyNameBtn {
  display: flex;
  align-items: center;
  justify-content: center; /* center the text horizontally */
  height: 80px;  /* fixed height, adjust as needed */
  width: 220px;  /* fixed width, adjust as needed */
  padding: 0 15px; /* horizontal padding */
  padding-right: 490px;
  font-weight: 600;
  font-size: 14px;
  color: #2a5dff;
  background-color: #e6f0ff;
  border: 2px solid transparent;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  box-shadow: 0 3px 8px rgba(42, 93, 255, 0.15);
  transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
  position: relative;
  text-decoration: none;
  overflow: hidden;
  text-overflow: ellipsis;
}

.companyNameBtn .btn-text {
  display: inline-block;
  /* Shift text horizontally inside the button */
  margin-right: 120px;
  margin-left: 20px; /* Change this value to move text right or left */
  /* For vertical center alignment, no extra needed because flex and align-items center on parent */
}



.companyNameBtn:hover,
.companyNameBtn:focus {
  background-color: #2a5dff;
  color: #fff;
  border-color: #2248cc;
  box-shadow: 0 4px 12px rgb(34 72 204 / 0.3);
  outline: none;
}

/* Active company button */
.companyNameBtn.active {
  background-color: #2248cc;
  color: #fff;
  border-color: #1a3bb8;
  box-shadow: 0 6px 14px rgb(26 59 184 / 0.5);
  cursor: default;
  cursor: pointer;
}

/* Delete icon inside company button */
.companyNameBtn .deleteIcon {
  position: absolute;
  top: 50%;
  right: 8px;
  transform: translateY(-50%);
  font-size: 18px;
  color: #a0a0a0;
  cursor: pointer;
  transition: color 0.25s ease;
  background: transparent;
  border: none;
  padding: 0;
}

.companyNameBtn .deleteIcon:hover {
  color: #dc3545;
}

/* Delete form container */
.inlineDeleteForm {
  display: inline-block;
  margin: 0;
  position: absolute;
  top: 4px;
  right: 8px;
}

/* Create Company Button */
#createCompanyBtn {
  padding: 14px 36px;
  font-weight: 700;
  font-size: 20px;
  color: #fff;
  background-color: #2a5dff;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  user-select: none;
  box-shadow: 0 6px 12px rgb(42 93 255 / 0.4);
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  margin-left: 10px;
}

#createCompanyBtn:hover {
  background-color: #2248cc;
  box-shadow: 0 8px 16px rgb(34 72 204 / 0.6);
}

.info-text {
  font-size: 14px;
  color: #666;
  margin-top: 10px;
  margin-bottom: 10px;
}

.message-success {
  margin-left: 443px;
  max-width: 1000px;
  color: green;
  font-weight: 700;
  margin-bottom: 20px;
}

.message-error {
  margin-left: 443px;
  max-width: 1000px;
  color: #cc2222;
  font-weight: 700;
  margin-bottom: 20px;
}

/* Responsive */
@media (max-width: 900px) {
  .page-header, .container {
    margin-left: 20px;
    max-width: 100%;
  }
  .sidebar {
    flex-direction: row;
    max-width: 100%;
    gap: 15px;
  }
  .sidebar button {
    font-size: 16px;
    padding: 8px 12px;
    border-left: none;
    border-bottom: 4px solid transparent;
  }
  .sidebar button.active {
    border-left: none;
    border-bottom-color: #2a5dff;
  }
  .main-content {
    max-width: 100%;
  }
  #userGreeting {
    font-size: 1.8rem;
    margin-left: 10px;
  }
  .message-success, .message-error {
    margin-left: 20px;
    max-width: 100%;
  }
}
</style>
</head>
<body>

<!-- Navbar -->
<header class="navbar">
  <div class="logo">CCAM</div>

  <nav class="nav-left">
    <a href="#">Features</a>
    <a href="#">Pricing</a>
    <a href="#">Resources</a>
    <a href="#">About</a>
    <a href="#">Contact</a>
  </nav>

  <div class="nav-right" style="--nav-right-left-offset: -445px;">
    <button class="get-started-btn" id="getStartedBtn">Get Started</button>
  </div>
</header>

<!-- Page heading -->
<div class="page-header">
  <div>
    <h1>Dashboard</h1>
    <p>Your account dashboard</p>
  </div>

  <?php if ($username): ?>
  <div id="userGreeting" aria-label="Greeting">
    Hello, <?= htmlspecialchars($username) ?>
  </div>
  <?php endif; ?>
</div>

<?php if ($successMsg): ?>
  <div class="message-success" role="alert" aria-live="polite"><?= htmlspecialchars($successMsg) ?></div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
  <div class="message-error" role="alert" aria-live="assertive">
    <ul>
      <?php foreach ($errors as $err): ?>
        <li><?= htmlspecialchars($err) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<!-- Container -->
<div class="container">
  <!-- Sidebar -->
  <nav class="sidebar" aria-label="Dashboard navigation">
    <button class="active" type="button" onclick="activateSidebarItem(this)">Dashboard</button>
    <button type="button" onclick="activateSidebarItem(this)">Profile</button>
    <button type="button" onclick="activateSidebarItem(this)">Password</button>
    <button type="button" onclick="activateSidebarItem(this)">Logout</button>
  </nav>

  <!-- Main content -->
  <div class="main-content" role="main" aria-label="Company dashboard and controls" style="margin-top: 180px;">

    <?php if (count($companies) > 0): ?>
      <div class="info-text" aria-live="polite" role="status">
      
      </div>
      <hr />
    <?php endif; ?>

    <div id="companyButtons" role="list" aria-label="List of your companies">
      <?php foreach ($companies as $company): ?>
        <div style="display: inline-block; position: relative; margin-right: 12px; margin-bottom: 10px;">
          <!-- Company link to select -->
          <a
  href="company/company_dashboard.php?company_id=<?= $company['id'] ?>"
  class="companyNameBtn"
  aria-label="Go to company <?= htmlspecialchars($company['company_name']) ?> dashboard"
  data-id="<?= $company['id'] ?>"
  style="display: inline-block; padding-right: 30px; position: relative;"
>
  <span class="btn-text"><?= htmlspecialchars($company['company_name']) ?></span>
</a>


          <!-- Delete form/button -->
          <form method="POST" class="inlineDeleteForm" style="display: inline; position: absolute; top: 4px; right: 4px;">
            <input type="hidden" name="delete_company_id" value="<?= $company['id'] ?>">
            <button
              type="submit"
              name="delete"
              value="1"
              class="deleteIcon"
              title="Delete <?= htmlspecialchars($company['company_name']) ?>"
              onclick="return confirm('Delete this company?');"
              style="font-size: 18px; background: none; border: none; color: #adb5bd; cursor: pointer;"
              onmouseover="this.style.color='#dc3545';"
              onmouseout="this.style.color='#adb5bd';"
            >&times;</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if (count($companies) > 0): ?>
      <hr />
      <div class="info-text" aria-live="polite" role="status">
        Showing 1 to <?= count($companies) ?> of <?= count($companies) ?> companies
      </div>
    <?php endif; ?>

    <button id="createCompanyBtn" aria-label="Create new company">+ Create</button>

  </div>
</div>

<script>
  const sidebarButtons = document.querySelectorAll('.sidebar button');
  const dashboardContent = document.getElementById('dashboardContent');
  const otherContent = document.getElementById('otherContent');

  sidebarButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      sidebarButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const selected = btn.textContent.trim();

      if (selected === 'Dashboard') {
        if(dashboardContent) dashboardContent.style.display = 'block';
        if(otherContent) otherContent.style.display = 'none';
      } else if (selected === 'Logout') {
        window.location.href = 'logout.php';
      } else {
        if(dashboardContent) dashboardContent.style.display = 'none';
        if(otherContent) {
          otherContent.style.display = 'block';
          otherContent.textContent = `Content for "${selected}" coming soon.`;
        }
      }
    });
  });

  function activateSidebarItem(button) {
    sidebarButtons.forEach(b => b.classList.remove('active'));
    button.classList.add('active');
  }

  document.getElementById('getStartedBtn').addEventListener('click', function() {
    window.location.href = 'setup/cloud.php';
  });

  document.getElementById('createCompanyBtn').addEventListener('click', function() {
    window.location.href = 'setup/cloud.php';
  });
  
</script>

<script>
  // Get all company buttons
  const companyButtons = document.querySelectorAll('.companyNameBtn');

  // Remove active class from all (just in case)
  companyButtons.forEach(btn => btn.classList.remove('active'));

  // Add click listener to each button
  companyButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Remove active class from all buttons
      companyButtons.forEach(b => b.classList.remove('active'));
      // Add active class to clicked button
      btn.classList.add('active');
    });
  });
</script>


</body>
</html>
