<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing company_id']);
    exit;
}

$stmt = $mysqli->prepare("SELECT COUNT(*) AS unpaid_count, COALESCE(SUM(amount_due), 0) AS total_due FROM receivables WHERE company_id = ? AND status = 'unpaid'");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $data = $result->fetch_assoc();
    echo json_encode([
        'unpaidCount' => (int)$data['unpaid_count'],
        'totalDue' => (float)$data['total_due'],
    ]);
} else {
    echo json_encode(['error' => 'Query failed']);
}

$stmt->close();
exit;
