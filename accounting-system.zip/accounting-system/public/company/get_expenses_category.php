<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing company_id']);
    exit;
}

$stmt = $mysqli->prepare("
    SELECT category, COALESCE(SUM(amount), 0) AS total_amount
    FROM expenses_by_category
    WHERE company_id = ?
    GROUP BY category
    ORDER BY total_amount DESC
");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$result = $stmt->get_result();

$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[] = [
        'category' => $row['category'],
        'totalAmount' => (float)$row['total_amount'],
    ];
}

echo json_encode(['categories' => $categories]);

$stmt->close();
exit;
