<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

require_once '../../config/db.php';  // Adjust path if needed

$user_id = $_SESSION['user']['id'];
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'No input or invalid JSON']);
    exit;
}

error_log("Received input: " . print_r($input, true));

$allowed_types = ['Receivables', 'Payables', 'CashFlow'];

// Get company_id from GET or JSON payload
$company_id = 0;
if ($method === 'GET') {
    $company_id = isset($_GET['company_id']) ? intval($_GET['company_id']) : 0;
} else {
    $company_id = isset($input['company_id']) ? intval($input['company_id']) : 0;
}

if (!$company_id) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid company_id']);
    exit;
}

// Verify that user owns this company before proceeding
$stmtCheck = $mysqli->prepare("SELECT id FROM companies WHERE id = ? AND user_id = ?");
$stmtCheck->bind_param("ii", $company_id, $user_id);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();
if ($resultCheck->num_rows === 0) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied: company not found or not owned by user']);
    exit;
}
$stmtCheck->close();


switch ($method) {
    case 'GET':
        $stmt = $mysqli->prepare("SELECT * FROM widgets WHERE company_id = ? ORDER BY sort_order ASC");
        $stmt->bind_param("i", $company_id);
        $stmt->execute();
        $widgets = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        echo json_encode(['widgets' => $widgets]);
        break;

    case 'POST':
        $name = trim($input['name'] ?? '');
        $type = trim($input['type'] ?? '');
        $width = trim($input['width'] ?? '50%');
        $sort_order = isset($input['sort_order']) ? (int)$input['sort_order'] : 1;

        if (!$name || !$type || !in_array($type, $allowed_types)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input']);
            exit;
        }

        $stmt = $mysqli->prepare("INSERT INTO widgets (user_id, company_id, name, type, width, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisssi", $user_id, $company_id, $name, $type, $width, $sort_order);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'widget_id' => $stmt->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Insert failed: ' . $stmt->error]);
        }
        $stmt->close();
        break;

    case 'PUT':
        $widget_id = $input['widget_id'] ?? 0;
        $name = trim($input['name'] ?? '');
        $type = trim($input['type'] ?? '');
        $width = trim($input['width'] ?? '50%');
        $sort_order = isset($input['sort_order']) ? (int)$input['sort_order'] : 1;

        if (!$widget_id || !$name || !$type || !in_array($type, $allowed_types)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input']);
            exit;
        }

        // Verify widget belongs to company
        $stmtCheck = $mysqli->prepare("SELECT widget_id FROM widgets WHERE widget_id = ? AND company_id = ?");
        $stmtCheck->bind_param("ii", $widget_id, $company_id);
        $stmtCheck->execute();
        $resCheck = $stmtCheck->get_result();
        if ($resCheck->num_rows === 0) {
            http_response_code(403);
            echo json_encode(['error' => 'Widget not found or unauthorized']);
            exit;
        }
        $stmtCheck->close();

        $stmt = $mysqli->prepare("UPDATE widgets SET name = ?, type = ?, width = ?, sort_order = ? WHERE widget_id = ? AND company_id = ?");
        $stmt->bind_param("sssiii", $name, $type, $width, $sort_order, $widget_id, $company_id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Update failed: ' . $stmt->error]);
        }
        $stmt->close();
        break;

    case 'DELETE':
        $widget_id = $input['widget_id'] ?? 0;
        if (!$widget_id) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing widget_id']);
            exit;
        }

        // Verify widget ownership
        $stmtCheck = $mysqli->prepare("SELECT widget_id FROM widgets WHERE widget_id = ? AND company_id = ?");
        $stmtCheck->bind_param("ii", $widget_id, $company_id);
        $stmtCheck->execute();
        $resCheck = $stmtCheck->get_result();
        if ($resCheck->num_rows === 0) {
            http_response_code(403);
            echo json_encode(['error' => 'Widget not found or unauthorized']);
            exit;
        }
        $stmtCheck->close();

        $stmt = $mysqli->prepare("DELETE FROM widgets WHERE widget_id = ? AND company_id = ?");
        $stmt->bind_param("ii", $widget_id, $company_id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Delete failed: ' . $stmt->error]);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method Not Allowed']);
        break;
}
