<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 5;

if ($companyId === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid company_id']);
    exit;
}

$offset = ($page - 1) * $perPage;

// Count total upcoming payables
$countStmt = $mysqli->prepare("SELECT COUNT(*) AS total FROM payables WHERE company_id = ? AND due_date >= CURDATE()");
$countStmt->bind_param("i", $companyId);
$countStmt->execute();
$countResult = $countStmt->get_result()->fetch_assoc();
$total = $countResult['total'] ?? 0;
$countStmt->close();

// Fetch paginated upcoming payables
$stmt = $mysqli->prepare("
    SELECT id, description, amount_due, due_date, status
    FROM payables
    WHERE company_id = ? AND due_date >= CURDATE()
    ORDER BY due_date ASC
    LIMIT ? OFFSET ?
");
$stmt->bind_param("iii", $companyId, $perPage, $offset);
$stmt->execute();
$result = $stmt->get_result();

$payables = [];
while ($row = $result->fetch_assoc()) {
    $payables[] = $row;
}
$stmt->close();

echo json_encode([
    'total' => $total,
    'page' => $page,
    'perPage' => $perPage,
    'payables' => $payables,
]);
exit;
?>
