<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

$id = (int)($input['id'] ?? 0);
$description = trim($input['description'] ?? '');
$amountDue = floatval($input['amount_due'] ?? 0);
$dueDate = $input['due_date'] ?? null;
$status = $input['status'] ?? null;

if ($id === 0 || $description === '' || $amountDue <= 0 || !$dueDate || !$status) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid required fields']);
    exit;
}

$allowedStatuses = ['unpaid', 'paid', 'overdue'];
if (!in_array($status, $allowedStatuses)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid status']);
    exit;
}

$stmt = $mysqli->prepare("UPDATE payables SET description = ?, amount_due = ?, due_date = ?, status = ? WHERE id = ?");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to prepare statement']);
    exit;
}

$stmt->bind_param("sdssi", $description, $amountDue, $dueDate, $status, $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update payable']);
}

$stmt->close();
exit;
?>
