<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

$companyId = (int)($input['company_id'] ?? 0);
$description = trim($input['description'] ?? '');
$amountDue = floatval($input['amount_due'] ?? 0);
$dueDate = $input['due_date'] ?? null;
$status = $input['status'] ?? 'unpaid';

// Basic validation
if ($companyId === 0 || $description === '' || $amountDue <= 0 || !$dueDate) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid required fields']);
    exit;
}

$allowedStatuses = ['unpaid', 'paid', 'overdue'];
if (!in_array($status, $allowedStatuses)) {
    $status = 'unpaid';
}

$stmt = $mysqli->prepare("INSERT INTO payables (company_id, description, amount_due, due_date, status) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to prepare statement']);
    exit;
}

$stmt->bind_param("isdss", $companyId, $description, $amountDue, $dueDate, $status);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to insert payable']);
}

$stmt->close();
exit;
?>
