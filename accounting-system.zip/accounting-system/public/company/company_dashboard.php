<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$company_id = null;
if (isset($_GET['company_id']) && !empty($_GET['company_id'])) {
    $company_id = (int)$_GET['company_id'];
    $_SESSION['company_id'] = $company_id; // store in session for next requests
} elseif (isset($_SESSION['company_id'])) {
    $company_id = (int)$_SESSION['company_id'];
}

if (!$company_id) {
    echo "Missing company ID";
    exit;
}

$username = $_SESSION['user']['name'] ?? 'User';
$companyName = $_SESSION['company_name'] ?? 'moole ent.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?= htmlspecialchars($companyName) ?> Dashboard</title>

<!-- ===== CSS Styles ===== -->
<style>
  /* Basic Reset & Layout */
  * {
    margin: 0; padding: 0; box-sizing: border-box;
  }
  body {
    font-family: "Inter", sans-serif;
    background: #fff;
    color: #1a1a1a;
  }

  /* Sidebar styles */
  .sidebar {
    width: 244px;
    background: #edf0ff;
    height: 100vh;
    position: fixed;
    left: 0; top: 0;
    padding-top: 18px;
    border-right: 1px solid #e5e7eb;
    display: flex; flex-direction: column;
  }
  .sidebar-logo {
    font-size: 17px;
    font-weight: 600;
    padding: 0 20px 25px;
    color: #333;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .sidebar-nav {
    display: flex; flex-direction: column;
  }
  .nav-item {
    padding: 9px 20px;
    color: #374151;
    font-size: 14px;
    text-decoration: none;
    border-radius: 6px;
    margin: 2px 10px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .nav-item:hover {
    background-color: #e0e7ff;
    color: #111827;
  }

  /* Main content area */
  .main {
    margin-left: 244px;
    padding: 26px 34px;
  }

  /* Header styles */
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .header h1 {
    font-size: 26px;
    font-weight: 600;
    color: #1f2937;
  }
  .header-controls {
    display: flex;
    gap: 15px;
    font-size: 14px;
  }
  .header-controls a {
    color: #4f46e5;
    text-decoration: none;
    cursor: pointer;
  }

  /* Widget grid container */
  .widget-grid {
    margin-top: 24px;
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
  }

  /* Widget base styles (receivables/payables share) */
  .widget-receivables {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border: 1px solid #f3f4f6;
    padding: 20px;
    width: 360px;
    position: relative;
    display: flex;
    flex-direction: column;
  }

  /* Widget header and title */
  .widget-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .widget-title {
    font-weight: 600;
    font-size: 16px;
    color: #374151;
  }

  /* Widget options button */
  .widget-options-btn {
    background: none;
    border: none;
    font-size: 22px;
    cursor: pointer;
    user-select: none;
  }

  /* Widget options menu */
  .widget-options {
    position: absolute;
    top: 35px;
    right: 20px;
    background: #fff;
    border: 1px solid #ccc;
    border-radius: 4px;
    padding: 5px 0;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
    z-index: 100;
    min-width: 100px;
    display: none;
  }
  .widget-options button {
    width: 100%;
    border: none;
    background: none;
    padding: 8px 12px;
    cursor: pointer;
    text-align: left;
  }
  .widget-options button:hover {
    background-color: #f0f0f0;
  }
  .widget-options button.selected {
    background-color: #c7d2fe;
    font-weight: 600;
  }

  /* Widget description */
  .widget-desc {
    margin-top: 8px;
    font-size: 14px;
    color: #6b7280;
  }

  /* Divider line */
  .divider {
    border-top: 1px solid #e5e7eb;
    margin: 18px 0;
  }

  /* Amount text */
  .amount {
    font-weight: 600;
    font-size: 20px;
    margin-bottom: 12px;
  }

  /* Progress bar container */
  .bar-container {
    background: #e0e7ff;
    height: 10px;
    border-radius: 5px;
    overflow: hidden;
    margin-bottom: 16px;
  }
  .bar-fill {
    background: #4f46e5;
    height: 100%;
    width: 0;
    transition: width 0.5s ease;
  }

  /* Open and overdue sections */
  .open-overdue {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
  }
  .open-overdue > div {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  /* Toggle arrow button */
  .toggle-arrow {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    user-select: none;
    margin-left: 6px;
  }

  /* Overdue details popup */
  .overdue-details {
    font-size: 13px;
    color: #4b5563;
    margin-top: 6px;
    position: absolute;
    right: 0;
    top: 100%;
    width: max-content;
    background: transparent !important;
    border: none !important;
    padding: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;

    display: flex;
    flex-direction: column;
    gap: 4px;
    z-index: 1000;
  }
  .overdue-details button {
    background: transparent;
    border: none;
    color: #4b5563;
    text-align: left;
    padding: 2px 6px;
    cursor: pointer;
    border-bottom: 1px solid #e5e7eb;
    font-size: 13px;
    transition: background-color 0.2s;
    width: 100%;
  }
  .overdue-details button:last-child {
    border-bottom: none;
  }
  .overdue-details button:hover {
    background-color: #e0e7ff;
  }

  /* Modal overlay */
  #widgetModal {
    display: none;
    position: fixed;
    top:0; left:0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.4);
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }
  #widgetModal > div {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    width: 400px;
    max-width: 90%;
  }
  #widgetModal h3 {
    margin-bottom: 15px;
    font-weight: 600;
    color: #333;
  }
  #widgetForm label {
    display: block;
    margin-bottom: 10px;
    font-weight: 500;
    color: #555;
  }
  #widgetForm input[type="text"],
  #widgetForm select,
  #widgetForm input[type="number"] {
    width: 100%;
    padding: 6px 8px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  #widgetForm button {
    padding: 8px 16px;
    font-size: 14px;
    margin-right: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  #widgetForm button[type="submit"] {
    background-color: #4f46e5;
    color: white;
  }
  #cancelBtn {
    background-color: #ccc;
    color: #333;
  }

  /* Cash Flow Widget styles */
  .widget-cashflow {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border: 1px solid #f3f4f6;
    padding: 20px;
    width: 360px;
    position: relative;
    display: flex;
    flex-direction: column;
  }
  .cashflow-summary {
    font-weight: 600;
    font-size: 20px;
    margin-bottom: 18px;
    display: flex;
    justify-content: center;
    gap: 12px;
    align-items: center;
  }
  .cashflow-amount {
    min-width: 80px;
    text-align: center;
  }
  .cashflow-incoming {
    color: #16a34a;
  }
  .cashflow-outgoing {
    color: #dc2626;
  }
  .cashflow-profit {
    color: #7c3aed;
  }
  .cashflow-symbols {
    display: flex;
    justify-content: center;
    gap: 24px;
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 18px;
  }
  .cashflow-symbol {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .cashflow-symbol .circle {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    display: inline-block;
  }
  .circle-green { background-color: #16a34a; }
  .circle-red { background-color: #dc2626; }
  .circle-purple { background-color: #7c3aed; }
  .cashflow-graph {
    width: 100%;
    height: 80px;
    position: relative;
    margin-bottom: 6px;
  }
  .cashflow-bar {
    position: absolute;
    bottom: 0;
    width: 12px;
    background-color: #4f46e5;
    border-radius: 4px 4px 0 0;
    transition: height 0.4s ease;
  }
  .cashflow-labels {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    color: #6b7280;
    user-select: none;
  }
</style>
</head>
<body>

<!-- Sidebar Navigation -->
<div class="sidebar">
  <div class="sidebar-logo">
    <span>🟢</span> <?= htmlspecialchars($companyName) ?>
  </div>
  <div class="sidebar-nav">
    <a href="#" class="nav-item">📊 Dashboard</a>
    <a href="#" class="nav-item">📦 Items</a>
    <a href="#" class="nav-item">💰 Sales</a>
    <a href="#" class="nav-item">🛒 Purchases</a>
    <a href="#" class="nav-item">🏦 Banking</a>
    <a href="#" class="nav-item">📑 Reports</a>
    <a href="#" class="nav-item">🚀 Apps</a>
    <a href="#" class="nav-item">🔄 Switch</a>
  </div>
</div>

<!-- Main Content Area -->
<div class="main">
  <div class="header">
    <h1>Dashboard</h1>
    <div class="header-controls">
      <a href="#" id="addWidgetBtn">Add Widget</a>
      <a href="#">New Dashboard</a>
      <a href="../logout.php" style="color:#f44336;">Logout</a>
    </div>
  </div>

  <!-- Widget Grid Container -->
  <div class="widget-grid" id="widgetGrid"></div>
</div>

<!-- Widget Add/Edit Modal -->
<div id="widgetModal">
  <div>
    <h3 id="modalTitle">Add Widget</h3>
    <form id="widgetForm">
      <input type="hidden" name="widget_id" id="widget_id" value="" />

      <label>Name (required):<br/>
        <input type="text" name="name" id="name" required />
      </label>

      <label>Type (required):<br/>
        <select name="type" id="type" required>
          <option value="">-- Select Type --</option>
          <option value="Receivables">Receivables</option>
          <option value="Payables">Payables</option>
          <option value="CashFlow">Cash Flow</option>
        </select>
      </label>

      <label>Width:<br/>
        <select name="width" id="width">
          <option value="25%">25%</option>
          <option value="33%">33%</option>
          <option value="50%" selected>50%</option>
          <option value="100%">100%</option>
        </select>
      </label>

      <label>Sort Order:<br/>
        <input type="number" name="sort_order" id="sort_order" value="1" min="1" />
      </label>

      <br/>
      <button type="button" id="cancelBtn">Cancel</button>
      <button type="submit" id="saveBtn">Save</button>
    </form>
  </div>
</div>

<!-- ===== JavaScript ===== -->
<script>
const widgetGrid = document.getElementById('widgetGrid');
const widgetModal = document.getElementById('widgetModal');
const widgetForm = document.getElementById('widgetForm');
const modalTitle = document.getElementById('modalTitle');
const addWidgetBtn = document.getElementById('addWidgetBtn');
const widgetIdInput = document.getElementById('widget_id');
const nameInput = document.getElementById('name');
const typeSelect = document.getElementById('type');
const widthSelect = document.getElementById('width');
const sortOrderInput = document.getElementById('sort_order');
const cancelBtn = document.getElementById('cancelBtn');

let widgets = [];

// Get the company_id from PHP (passed via PHP variable)
const companyId = <?= json_encode($company_id) ?>;

// Open the Add Widget modal
addWidgetBtn.addEventListener('click', e => {
  e.preventDefault();
  modalTitle.textContent = 'Add Widget';
  widgetForm.reset();
  widgetIdInput.value = '';
  widgetModal.style.display = 'flex';
});

// Cancel button closes modal
cancelBtn.addEventListener('click', () => {
  widgetModal.style.display = 'none';
  widgetForm.reset();
});

// Format currency helper
function formatCurrency(amount, currency='₱') {
  return currency + Number(amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
}

// Render Receivables widget
function renderReceivablesWidget(widget) {
  // Dummy data placeholders
  const totalUnpaid = 0.00;
  const openAmount = 0.00;
  const overdueAmount = 0.00;
  const barPercent = 0;

  const container = document.createElement('div');
  container.className = 'widget-receivables';
  container.style.width = widget.width || '360px';

  container.innerHTML = `
    <div class="widget-header">
      <span class="widget-title">Receivables</span>
      <div style="position: relative;">
        <button class="widget-options-btn">⋮</button>
        <div class="widget-options" style="display:none;">
          <button class="edit-widget" data-id="${widget.widget_id}">Edit</button>
          <button class="delete-widget" data-id="${widget.widget_id}">Delete</button>
        </div>
      </div>
    </div>
    <div class="widget-desc">
      Amount that you're yet to receive from your customers
    </div>
    <div class="divider"></div>
    <div class="amount">Total unpaid invoices: ${formatCurrency(totalUnpaid)}</div>
    <div class="bar-container">
      <div class="bar-fill" style="width: ${barPercent}%;"></div>
    </div>
    <div class="open-overdue">
      <div>
        <div>Open</div>
        <div>${formatCurrency(openAmount)}</div>
      </div>
      <div>
        <div>Overdue</div>
        <div>${formatCurrency(overdueAmount)}</div>
      </div>
    </div>
  `;

  addWidgetOptionsListeners(container);
  return container;
}

// Render Payables widget
function renderPayablesWidget(widget) {
  const container = document.createElement('div');
  container.className = 'widget-receivables'; // reuse style for now
  container.style.width = widget.width || '360px';

  container.innerHTML = `
    <div class="widget-header">
      <span class="widget-title">Payables</span>
      <div style="position: relative;">
        <button class="widget-options-btn">⋮</button>
        <div class="widget-options" style="display:none;">
          <button class="edit-widget" data-id="${widget.widget_id}">Edit</button>
          <button class="delete-widget" data-id="${widget.widget_id}">Delete</button>
        </div>
      </div>
    </div>
    <div class="widget-desc">
      Amount that you need to pay to your suppliers
    </div>
    <div class="divider"></div>
    <div class="amount">Total unpaid bills: ₱0.00</div>
    <div class="bar-container">
      <div class="bar-fill" style="width: 0%;"></div>
    </div>
    <div class="open-overdue">
      <div>
        <div>Open</div>
        <div>₱0.00</div>
      </div>
      <div>
        <div>Overdue</div>
        <div>₱0.00</div>
      </div>
    </div>
  `;

  addWidgetOptionsListeners(container);
  return container;
}

// Render Cash Flow widget
function renderCashFlowWidget(widget) {
  const container = document.createElement('div');
  container.className = 'widget-cashflow';
  container.style.width = widget.width || '360px';

  // Dummy amounts for example
  const incoming = 200000;
  const outgoing = 150000;
  const profit = incoming - outgoing;

  container.innerHTML = `
    <div class="widget-header">
      <span class="widget-title">Cash Flow</span>
      <div style="position: relative;">
        <button class="widget-options-btn">⋮</button>
        <div class="widget-options" style="display:none;">
          <button class="edit-widget" data-id="${widget.widget_id}">Edit</button>
          <button class="delete-widget" data-id="${widget.widget_id}">Delete</button>
        </div>
      </div>
    </div>
    <div class="cashflow-summary">
      <div class="cashflow-amount cashflow-incoming">${formatCurrency(incoming)}</div>
      <div>→</div>
      <div class="cashflow-amount cashflow-outgoing">${formatCurrency(outgoing)}</div>
      <div>=</div>
      <div class="cashflow-amount cashflow-profit">${formatCurrency(profit)}</div>
    </div>
    <div class="cashflow-symbols">
      <div class="cashflow-symbol"><span class="circle circle-green"></span>Incoming</div>
      <div class="cashflow-symbol"><span class="circle circle-red"></span>Outgoing</div>
      <div class="cashflow-symbol"><span class="circle circle-purple"></span>Profit</div>
    </div>
    <div class="cashflow-graph">
      <div class="cashflow-bar" style="left: 0; height: 80px;"></div>
      <div class="cashflow-bar" style="left: 40px; height: 60px;"></div>
      <div class="cashflow-bar" style="left: 80px; height: 70px;"></div>
      <div class="cashflow-bar" style="left: 120px; height: 40px;"></div>
      <div class="cashflow-bar" style="left: 160px; height: 30px;"></div>
      <div class="cashflow-bar" style="left: 200px; height: 70px;"></div>
      <div class="cashflow-bar" style="left: 240px; height: 60px;"></div>
      <div class="cashflow-bar" style="left: 280px; height: 50px;"></div>
    </div>
    <div class="cashflow-labels">
      <div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div><div>Sun</div><div>Mon</div>
    </div>
  `;

  addWidgetOptionsListeners(container);
  return container;
}

// Attach event listeners for widget options buttons
function addWidgetOptionsListeners(container) {
  const optionsBtn = container.querySelector('.widget-options-btn');
  const optionsMenu = container.querySelector('.widget-options');

  optionsBtn.addEventListener('click', e => {
    e.stopPropagation();
    // Close all other open menus first
    document.querySelectorAll('.widget-options').forEach(menu => {
      if (menu !== optionsMenu) menu.style.display = 'none';
    });
    optionsMenu.style.display = optionsMenu.style.display === 'block' ? 'none' : 'block';
  });

  // Clicking outside closes menus
  document.addEventListener('click', () => {
    optionsMenu.style.display = 'none';
  });

  // Edit widget button
  optionsMenu.querySelector('.edit-widget').addEventListener('click', e => {
    e.preventDefault();
    const id = e.target.dataset.id;
    openEditWidgetModal(id);
    optionsMenu.style.display = 'none';
  });

  // Delete widget button
  optionsMenu.querySelector('.delete-widget').addEventListener('click', e => {
    e.preventDefault();
    const id = e.target.dataset.id;
    if (confirm('Are you sure you want to delete this widget?')) {
      deleteWidget(id);
    }
    optionsMenu.style.display = 'none';
  });
}

// Load widgets from API
function loadWidgets() {
  fetch(`widgets_api.php?company_id=${companyId}`)
    .then(res => res.json())
    .then(data => {
      if (data.widgets) {
        widgets = data.widgets;
        renderWidgets();
      } else {
        widgetGrid.innerHTML = '<p>No widgets found.</p>';
      }
    })
    .catch(() => {
      widgetGrid.innerHTML = '<p>Error loading widgets.</p>';
    });
}

// Render all widgets in the grid
function renderWidgets() {
  widgetGrid.innerHTML = '';
  widgets.forEach(widget => {
    let widgetElement;
    switch (widget.type) {
      case 'Receivables':
        widgetElement = renderReceivablesWidget(widget);
        break;
      case 'Payables':
        widgetElement = renderPayablesWidget(widget);
        break;
      case 'CashFlow':
        widgetElement = renderCashFlowWidget(widget);
        break;
      default:
        widgetElement = document.createElement('div');
        widgetElement.textContent = `Unknown widget type: ${widget.type}`;
    }
    widgetGrid.appendChild(widgetElement);
  });
}

// Open modal with data for editing widget
function openEditWidgetModal(id) {
  const widget = widgets.find(w => w.widget_id == id);
  if (!widget) return;

  modalTitle.textContent = 'Edit Widget';
  widgetIdInput.value = widget.widget_id;
  nameInput.value = widget.name;
  typeSelect.value = widget.type;
  widthSelect.value = widget.width || '50%';
  sortOrderInput.value = widget.sort_order || 1;

  widgetModal.style.display = 'flex';
}

// Delete widget via API
function deleteWidget(id) {
  fetch('widgets_api.php', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ widget_id: id, company_id: companyId }),
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      widgets = widgets.filter(w => w.widget_id != id);
      renderWidgets();
    } else {
      alert(data.error || 'Failed to delete widget');
    }
  })
  .catch(() => alert('Error deleting widget'));
}

// Submit form handler for add/edit widget
widgetForm.addEventListener('submit', e => {
  e.preventDefault();

  const id = widgetIdInput.value.trim();
  const payload = {
    name: nameInput.value.trim(),
    type: typeSelect.value,
    width: widthSelect.value,
    sort_order: parseInt(sortOrderInput.value, 10) || 1,
    company_id: companyId,
  };

  let url = 'widgets_api.php';
  let method = 'POST';

  if (id) {
    method = 'PUT';
    payload.widget_id = id;
  }

  fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      widgetModal.style.display = 'none';
      loadWidgets();
    } else {
      alert(data.error || 'Failed to save widget');
    }
  })
  .catch(() => alert('Error saving widget'));
});

// Initial load
loadWidgets();

</script>

</body>
</html>
