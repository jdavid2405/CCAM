<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$company_id = null;
if (!empty($_GET['company_id'])) {
    $company_id = (int)$_GET['company_id'];
    $_SESSION['company_id'] = $company_id;
} elseif (!empty($_SESSION['company_id'])) {
    $company_id = (int)$_SESSION['company_id'];
}

if (!$company_id) {
    echo "Missing company ID";
    exit;
}

$username = $_SESSION['user']['name'] ?? 'User';
$companyName = $_SESSION['company_name'] ?? 'moole ent.';

require_once __DIR__ . '/../../config/db.php'; // Adjust if needed

// Fetch widgets from DB for this company
$widgets = [];
$stmt = $mysqli->prepare("SELECT widget_id, name, type, width FROM widgets WHERE company_id = ? ORDER BY created_at ASC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $widgets[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?= htmlspecialchars($companyName) ?> Dashboard</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />

<style>
  /* Your existing styles here */
  * {
    margin: 0; padding: 0; box-sizing: border-box;
  }
  body {
    font-family: "Inter", sans-serif;
    background: #fff;
    color: #1a1a1a;
  }
  .sidebar {
    width: 244px;
    background: #edf0ff;
    height: 100vh;
    position: fixed;
    left: 0; top: 0;
    padding-top: 18px;
    border-right: 1px solid #e5e7eb;
    display: flex; flex-direction: column;
  }
  .sidebar-logo {
    font-size: 17px;
    font-weight: 600;
    padding: 0 20px 25px;
    color: #333;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .sidebar-nav {
    display: flex; flex-direction: column;
  }
  .nav-item {
    padding: 9px 20px;
    color: #374151;
    font-size: 14px;
    text-decoration: none;
    border-radius: 6px;
    margin: 2px 10px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .nav-item:hover {
    background-color: #e0e7ff;
    color: #111827;
  }
  .main {
    margin-left: 244px;
    padding: 26px 34px;
  }
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .header h1 {
    font-size: 26px;
    font-weight: 600;
    color: #1f2937;
  }
  .header-controls {
    display: flex;
    gap: 15px;
    font-size: 14px;
  }
  .header-controls a, .header-controls button {
    color: #4f46e5;
    text-decoration: none;
    cursor: pointer;
    background: none;
    border: none;
    font: inherit;
  }
  .widget-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 20px;
  }
  .widget-col {
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 15px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    /* Bootstrap column width classes fallback */
    flex: 0 0 auto;
  }
  /* Map widgetWidth to Bootstrap columns (optional) */
  .col-3 { width: 25%; }
  .col-4 { width: 33.33%; }
  .col-6 { width: 50%; }
  .col-12 { width: 100%; }
  .widget-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .widget-title {
    font-weight: 600;
    font-size: 18px;
  }
  .widget-controls button {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 16px;
    color: #6c757d;
  }
  .widget-data {
    margin-top: 10px;
    font-size: 14px;
  }
</style>
</head>
<body>

<!-- Sidebar Navigation -->
<div class="sidebar">
  <div class="sidebar-logo">
    <span>🟢</span> <?= htmlspecialchars($companyName) ?>
  </div>
  <nav class="sidebar-nav" aria-label="Main navigation">
    <a href="#" class="nav-item">📊 Dashboard</a>
    <a href="#" class="nav-item">📦 Items</a>
    <a href="#" class="nav-item">💰 Sales</a>
    <a href="#" class="nav-item">🛒 Purchases</a>
    <a href="#" class="nav-item">🏦 Banking</a>
    <a href="#" class="nav-item">📑 Reports</a>
    <a href="#" class="nav-item">🚀 Apps</a>
    <a href="#" class="nav-item">🔄 Switch</a>
  </nav>
</div>

<!-- Main Content Area -->
<div class="main">
  <div class="header">
    <h1>Dashboard</h1>
    <div class="header-controls">
      <button id="addWidgetBtn" class="btn btn-link">Add Widget</button>
      <a href="#" class="btn btn-link">New Dashboard</a>
      <a href="../logout.php" style="color:#f44336;">Logout</a>
    </div>
  </div>

  <!-- Widget Grid Container -->
  <div class="widget-grid" id="widgetGrid"></div>
</div>

<!-- Bootstrap Modal for Adding Widgets -->
<div class="modal fade" id="addWidgetModal" tabindex="-1" aria-labelledby="addWidgetModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addWidgetModalLabel">Add Widget</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="addWidgetModalBody">
        <div class="text-center py-5">Loading...</div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
  const widgetGrid = document.getElementById('widgetGrid');
  const addWidgetBtn = document.getElementById('addWidgetBtn');
  const addWidgetModal = new bootstrap.Modal(document.getElementById('addWidgetModal'), {
    keyboard: true,
    backdrop: 'static'
  });
  const addWidgetModalBody = document.getElementById('addWidgetModalBody');

  const companyId = <?= json_encode($company_id) ?>;

  addWidgetBtn.addEventListener('click', () => {
    addWidgetModalBody.innerHTML = '<div class="text-center py-5">Loading...</div>';
    addWidgetModal.show();

    fetch('add_widget.php?company_id=' + encodeURIComponent(companyId))
      .then(res => res.text())
      .then(html => {
        addWidgetModalBody.innerHTML = html;
      })
      .catch(() => {
        addWidgetModalBody.innerHTML = '<div class="text-danger text-center py-5">Failed to load form.</div>';
      });
  });

  // Render all widgets from PHP data
  function renderWidgets(widgets) {
    widgetGrid.innerHTML = '';
    widgets.forEach(data => {
      addWidgetCard(data);
    });
  }

  // Create widget card
  function addWidgetCard(data) {
    const widgetCol = document.createElement('div');
    widgetCol.className = `widget-col col-${data.width || 6}`;
    widgetCol.dataset.widgetId = data.widget_id;

    widgetCol.innerHTML = `
      <div class="widget-header">
        <div class="widget-title">${escapeHtml(data.name)}</div>
        <div class="widget-controls">
          <button title="Edit" onclick="editWidget(${data.widget_id})">✏️</button>
          <button title="Delete" onclick="deleteWidget(${data.widget_id})">🗑️</button>
        </div>
      </div>
      <div class="widget-data">Loading data...</div>
    `;

    widgetGrid.appendChild(widgetCol);

    // Fetch and render live data for this widget type
    fetchAndRenderWidgetData(widgetCol, data.type, companyId);
  }

  // Escape HTML for safety
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Fetch and render widget data based on type
  function fetchAndRenderWidgetData(widgetCol, widgetType, companyId) {
    let url = '';
    switch(widgetType) {
      case 'payables':
        url = `get_payables.php?company_id=${companyId}`;
        break;
      case 'receivables':
        url = `get_receivables.php?company_id=${companyId}`;
        break;
      case 'cash_flow':
        url = `get_cash_flow.php?company_id=${companyId}`;
        break;
      case 'profit_loss':
        url = `get_profit_loss.php?company_id=${companyId}`;
        break;
      case 'expenses_category':
        url = `get_expenses_category.php?company_id=${companyId}`;
        break;
      case 'account_balance':
        url = `get_account_balance.php?company_id=${companyId}`;
        break;
      case 'currencies':
        url = `get_currencies.php`;
        break;
      default:
        widgetCol.querySelector('.widget-data').textContent = 'No data available for this widget type.';
        return;
    }

    fetch(url)
      .then(res => res.json())
      .then(data => {
        if(data.error){
          widgetCol.querySelector('.widget-data').textContent = 'Error loading data';
          return;
        }
        renderWidgetData(widgetCol, widgetType, data);
      })
      .catch(() => {
        widgetCol.querySelector('.widget-data').textContent = 'Failed to fetch data';
      });
  }

  // Render widget data content
  function renderWidgetData(widgetCol, widgetType, data) {
    let html = '';

    switch(widgetType) {
      case 'payables':
        html = `
          <p><strong>Total Due:</strong> ₱${data.totalDue.toFixed(2)}</p>
          <p><strong>Unpaid Invoices:</strong> ${data.unpaidCount}</p>
        `;
        break;

      case 'receivables':
        html = `
          <p><strong>Total Due:</strong> ₱${data.totalDue.toFixed(2)}</p>
          <p><strong>Unpaid Receivables:</strong> ${data.unpaidCount}</p>
        `;
        break;

      case 'cash_flow':
        html = `
          <p><strong>Total Inflow:</strong> ₱${data.totalInflow.toFixed(2)}</p>
          <p><strong>Total Outflow:</strong> ₱${data.totalOutflow.toFixed(2)}</p>
        `;
        break;

      case 'profit_loss':
        html = `
          <p><strong>Total Income:</strong> ₱${data.totalIncome.toFixed(2)}</p>
          <p><strong>Total Expense:</strong> ₱${data.totalExpense.toFixed(2)}</p>
          <p><strong>Net Profit:</strong> ₱${data.netProfit.toFixed(2)}</p>
        `;
        break;

      case 'expenses_category':
        html = `<strong>Expenses by Category:</strong><ul>`;
        data.categories.forEach(cat => {
          html += `<li>${cat.category}: ₱${cat.totalAmount.toFixed(2)}</li>`;
        });
        html += `</ul>`;
        break;

      case 'account_balance':
        html = `<strong>Account Balances:</strong><ul>`;
        data.accounts.forEach(acc => {
          html += `<li>${acc.accountName}: ₱${acc.balance.toFixed(2)}</li>`;
        });
        html += `</ul>`;
        break;

      case 'currencies':
        html = `<strong>Currencies:</strong><ul>`;
        data.currencies.forEach(c => {
          html += `<li>${c.code} (${c.name}): Rate ${c.rate}</li>`;
        });
        html += `</ul>`;
        break;

      default:
        html = `<p>No data available.</p>`;
    }

    widgetCol.querySelector('.widget-data').innerHTML = html;
  }

  // Edit widget (placeholder)
  function editWidget(id) {
    alert('Edit widget ' + id);
    // You can implement the edit functionality later
  }

  // Delete widget
  function deleteWidget(id) {
    if (!confirm('Are you sure you want to delete this widget?')) return;

    fetch('delete_widget.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ widgetId: id, companyId })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        const widgetEl = widgetGrid.querySelector(`[data-widget-id="${id}"]`);
        if (widgetEl) widgetEl.remove();
      } else {
        alert('Failed to delete widget');
      }
    })
    .catch(() => alert('Failed to delete widget'));
  }

  // Submit add/edit widget form via AJAX
  document.addEventListener('submit', function(event) {
    if (event.target && event.target.id === 'addWidgetForm') {
      event.preventDefault();

      const form = event.target;
      const formData = new FormData(form);

      fetch('save_widget.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          addWidgetModal.hide();

          // Update existing widget or add new widget card
          const existingWidget = widgetGrid.querySelector(`[data-widget-id="${data.widgetId}"]`);
          if (existingWidget) {
            existingWidget.querySelector('.widget-title').textContent = data.widgetName;
            existingWidget.dataset.widgetWidth = data.widgetWidth;
            // Optionally refresh widget live data here
          } else {
            addWidgetCard({
              widget_id: data.widgetId,
              name: data.widgetName,
              type: data.widgetType,
              width: data.widgetWidth
            });
          }
        } else {
          alert('Error: ' + (data.error || 'Failed to save widget'));
        }
      })
      .catch(() => alert('Failed to save widget'));
    }
  });

  // Initial render of widgets loaded from PHP
  renderWidgets(<?= json_encode($widgets) ?>);
</script>

</body>
</html>
