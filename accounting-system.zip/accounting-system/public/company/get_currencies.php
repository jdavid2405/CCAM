<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$stmt = $mysqli->prepare("
    SELECT currency_code, currency_name, exchange_rate
    FROM currencies
    ORDER BY currency_code ASC
");
$stmt->execute();
$result = $stmt->get_result();

$currencies = [];
while ($row = $result->fetch_assoc()) {
    $currencies[] = [
        'code' => $row['currency_code'],
        'name' => $row['currency_name'],
        'rate' => (float)$row['exchange_rate'],
    ];
}

echo json_encode(['currencies' => $currencies]);

$stmt->close();
exit;
