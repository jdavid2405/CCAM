<?php
session_start();

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo "Unauthorized";
    exit;
}

$company_id = $_GET['company_id'] ?? null;
if (!$company_id) {
    echo "Missing company ID";
    exit;
}
?>

<form id="addWidgetForm">
  <div class="mb-3">
    <label for="widgetName" class="form-label">Widget Name (Table Name)</label>
    <input type="text" class="form-control" id="widgetName" name="widgetName" required />
  </div>

  <div class="mb-3">
    <label for="widgetType" class="form-label">Widget Type</label>
    <select class="form-select" id="widgetType" name="widgetType" required>
      <option value="">Select Type</option>
      <option value="receivables">Receivables</option>
      <option value="payables">Payables</option>
      <option value="cash_flow">Cash Flow</option>
      <option value="profit_loss">Profit and Loss</option>
      <option value="expenses_category">Expenses by Category</option>
      <option value="account_balance">Account Balance</option>
      <option value="currencies">Currencies</option>
    </select>
  </div>

  <div class="mb-3">
    <label for="widgetWidth" class="form-label">Widget Width (Bootstrap columns)</label>
    <select class="form-select" id="widgetWidth" name="widgetWidth" required>
      <option value="6">6 (Half width)</option>
      <option value="12" selected>12 (Full width)</option>
      <option value="4">4 (One-third width)</option>
      <option value="3">3 (Quarter width)</option>
    </select>
  </div>

  <input type="hidden" name="companyId" value="<?= htmlspecialchars($company_id) ?>" />

  <div class="text-end">
    <button type="submit" class="btn btn-primary">Add Widget</button>
  </div>
</form>
