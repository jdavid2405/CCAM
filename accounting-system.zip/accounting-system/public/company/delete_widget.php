<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';
 // adjust path as needed

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$companyId = isset($data['companyId']) ? (int)$data['companyId'] : 0;
$widgetId = isset($data['widgetId']) ? (int)$data['widgetId'] : 0;

if ($companyId === 0 || $widgetId === 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit;
}

$stmt = $mysqli->prepare("DELETE FROM widgets WHERE widget_id = ? AND company_id = ?");
$stmt->bind_param("ii", $widgetId, $companyId);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Widget not found or already deleted']);
}

$stmt->close();
