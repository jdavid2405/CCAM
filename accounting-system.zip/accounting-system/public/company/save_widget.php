<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';
 // Adjust path as needed

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_POST['companyId'] ?? 0);
$widgetName = trim($_POST['widgetName'] ?? '');
$widgetType = $_POST['widgetType'] ?? '';
$widgetWidth = (int)($_POST['widgetWidth'] ?? 12);
$widgetId = isset($_POST['widgetId']) ? (int)$_POST['widgetId'] : null;

if ($companyId === 0 || !$widgetName || !$widgetType || !in_array($widgetWidth, [3,4,6,12], true)) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit;
}

if ($widgetId) {
    // Update existing widget
    $stmt = $mysqli->prepare("UPDATE widgets SET name = ?, type = ?, width = ?, updated_at = NOW() WHERE widget_id = ? AND company_id = ?");
    $stmt->bind_param("ssiii", $widgetName, $widgetType, $widgetWidth, $widgetId, $companyId);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        $success = true;
    } else {
        $success = false;
    }
    $stmt->close();

    echo json_encode([
        'success' => $success,
        'widgetName' => htmlspecialchars($widgetName),
        'widgetType' => htmlspecialchars($widgetType),
        'widgetWidth' => $widgetWidth,
        'widgetId' => $widgetId
    ]);
} else {
    // Insert new widget
    $stmt = $mysqli->prepare("INSERT INTO widgets (company_id, name, type, width) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issi", $companyId, $widgetName, $widgetType, $widgetWidth);
    $stmt->execute();

    $newId = $stmt->insert_id;
    $stmt->close();

    echo json_encode([
        'success' => true,
        'widgetName' => htmlspecialchars($widgetName),
        'widgetType' => htmlspecialchars($widgetType),
        'widgetWidth' => $widgetWidth,
        'widgetId' => $newId
    ]);
}
