<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing company_id']);
    exit;
}

$stmt = $mysqli->prepare("
    SELECT account_name, balance
    FROM account_balance
    WHERE company_id = ?
");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$result = $stmt->get_result();

$accounts = [];
while ($row = $result->fetch_assoc()) {
    $accounts[] = [
        'accountName' => $row['account_name'],
        'balance' => (float)$row['balance'],
    ];
}

echo json_encode(['accounts' => $accounts]);

$stmt->close();
exit;
