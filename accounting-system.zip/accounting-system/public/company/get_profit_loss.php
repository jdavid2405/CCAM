<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing company_id']);
    exit;
}

// Select the latest profit_loss record for this company
$stmt = $mysqli->prepare("
    SELECT total_revenue, total_expenses, net_profit
    FROM profit_loss
    WHERE company_id = ?
    ORDER BY id DESC
    LIMIT 1
");
$stmt->bind_param("i", $companyId);

if (!$stmt->execute()) {
    echo json_encode(['error' => 'Query execution failed: ' . $stmt->error]);
    exit;
}

$result = $stmt->get_result();
$data = $result->fetch_assoc();

if ($data) {
    echo json_encode([
        'totalIncome' => (float)$data['total_revenue'],
        'totalExpense' => (float)$data['total_expenses'],
        'netProfit' => (float)$data['net_profit'],
    ]);
} else {
    // No data found for this company — return zeros
    echo json_encode([
        'totalIncome' => 0,
        'totalExpense' => 0,
        'netProfit' => 0,
    ]);
}

$stmt->close();
exit;
