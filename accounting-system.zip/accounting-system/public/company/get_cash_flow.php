<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = (int)($_GET['company_id'] ?? 0);
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing company_id']);
    exit;
}

$stmt = $mysqli->prepare("
    SELECT
      COALESCE(SUM(CASE WHEN type = 'inflow' THEN amount ELSE 0 END), 0) AS total_inflow,
      COALESCE(SUM(CASE WHEN type = 'outflow' THEN amount ELSE 0 END), 0) AS total_outflow
    FROM cashflow
    WHERE company_id = ?
");
$stmt->bind_param("i", $companyId);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $data = $result->fetch_assoc();
    echo json_encode([
        'totalInflow' => (float)$data['total_inflow'],
        'totalOutflow' => (float)$data['total_outflow'],
    ]);
} else {
    echo json_encode(['error' => 'Query failed']);
}

$stmt->close();
exit;
