<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/db.php'; // Adjust path if needed

if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$companyId = isset($_GET['company_id']) ? (int)$_GET['company_id'] : 0;
if ($companyId === 0) {
    echo json_encode(['error' => 'Missing or invalid company_id']);
    exit;
}

// Query 1: Unpaid count and total amount due
$unpaidQuery = "SELECT COUNT(*) AS unpaid_count, COALESCE(SUM(amount_due), 0) AS total_unpaid FROM payables WHERE company_id = ? AND status = 'unpaid'";

// Query 2: Overdue count
$overdueQuery = "SELECT COUNT(*) AS overdue_count FROM payables WHERE company_id = ? AND status = 'overdue'";

// Query 3: Upcoming payables due in next 7 days
$upcomingQuery = "
    SELECT id, description, amount_due, due_date, status
    FROM payables
    WHERE company_id = ? AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    ORDER BY due_date ASC
    LIMIT 5
";

// Execute unpaid query
$stmt = $mysqli->prepare($unpaidQuery);
if (!$stmt) {
    echo json_encode(['error' => 'Failed to prepare unpaid query']);
    exit;
}
$stmt->bind_param("i", $companyId);
$stmt->execute();
$unpaidResult = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Execute overdue query
$stmt = $mysqli->prepare($overdueQuery);
if (!$stmt) {
    echo json_encode(['error' => 'Failed to prepare overdue query']);
    exit;
}
$stmt->bind_param("i", $companyId);
$stmt->execute();
$overdueResult = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Execute upcoming payables query
$stmt = $mysqli->prepare($upcomingQuery);
if (!$stmt) {
    echo json_encode(['error' => 'Failed to prepare upcoming query']);
    exit;
}
$stmt->bind_param("i", $companyId);
$stmt->execute();
$upcomingResult = $stmt->get_result();
$upcomingPayables = [];
while ($row = $upcomingResult->fetch_assoc()) {
    $upcomingPayables[] = $row;
}
$stmt->close();

// Return JSON response
echo json_encode([
    'unpaidCount' => (int)$unpaidResult['unpaid_count'],
    'totalUnpaid' => (float)$unpaidResult['total_unpaid'],
    'overdueCount' => (int)$overdueResult['overdue_count'],
    'upcomingPayables' => $upcomingPayables,
]);
exit;
