<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: index.php'); exit; }
require __DIR__ . '/../config/db.php';
$user = $_SESSION['user'];
// basic business info per user (single row)
$stmt = $pdo->prepare('SELECT * FROM business_info WHERE user_id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$info = $stmt->fetch();
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = $_POST['business_name'] ?? '';
    $email = $_POST['business_email'] ?? '';
    $phone = $_POST['business_phone'] ?? '';
    if($info){
        $up = $pdo->prepare('UPDATE business_info SET business_name=?, business_email=?, contact_number=? WHERE user_id=?');
        $up->execute([$name,$email,$phone,$user['id']]);
    } else {
        $ins = $pdo->prepare('INSERT INTO business_info (user_id,business_name,business_email,contact_number) VALUES (?,?,?,?)');
        $ins->execute([$user['id'],$name,$email,$phone]);
    }
    header('Location: settings.php'); exit;
}
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row">
  <div class="col-md-6">
    <h4>Business Info</h4>
    <form method="post">
      <div class="mb-3"><label>Business Name</label><input class="form-control" name="business_name" value="<?php echo htmlspecialchars($info['business_name'] ?? '');?>"></div>
      <div class="mb-3"><label>Business Email</label><input class="form-control" name="business_email" value="<?php echo htmlspecialchars($info['business_email'] ?? '');?>"></div>
      <div class="mb-3"><label>Contact Number</label><input class="form-control" name="business_phone" value="<?php echo htmlspecialchars($info['contact_number'] ?? '');?>"></div>
      <button class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
