<?php
session_start();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
$success = $_SESSION['success'] ?? '';

unset($_SESSION['errors'], $_SESSION['old'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Sign Up | CCAM</title>
<style>
  /* Reset and base */
* {
  box-sizing: border-box;
}
body {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  margin: 0;
  padding: 0;
  background: #f9fafb;
  color: #333;
}
a {
  color: #2a5dff;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}

/* Navbar */
.navbar {
  display: flex;
  align-items: center;
  background-color: #fff;
  padding: 15px 30px;
  box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
}

.navbar .logo {
  margin-right: auto;
  font-weight: 700;
  font-size: 32px;
  color: #2a5dff;
  cursor: pointer;
  margin-left: 443px;
}

/* Nav links container - left aligned after logo */
.nav-left {
  display: flex;
  gap: 30px;
  margin-right: 540px;
}

.nav-left a {
  font-weight: 600;
  font-size: 16px;
  color: #545557ff;
  text-decoration: none;
}

.nav-left a:hover {
  text-decoration: underline;
}

/* Right side buttons container */
.nav-right {
  display: flex;
  gap: 15px;
  position: relative;
  left: var(--nav-right-left-offset, 0);
}

/* Styled links as buttons */
.nav-right a {
  font-weight: 600;
  font-size: 16px;
  padding: 8px 18px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
}

/* Login button - outlined */
.login-btn {
  background: transparent;
  color: #2a5dff;
  border: 2px solid #2a5dff;
}

.login-btn:hover {
  background: #2a5dff;
  color: white;
}

/* Get Started button - filled */
.get-started-btn {
  background: #2a5dff;
  color: white;
}

.get-started-btn:hover {
  background: #2248cc;
}

/* Main container */
.container {
  display: flex;
  justify-content: space-between;
  max-width: 1000px;
  margin: 50px auto;
  padding: 0 20px;
  gap: 60px;
}

/* Left side text */
.left-text {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.left-text h1 {
  font-size: 2.5rem;
  font-weight: 900;
  margin: 0 0 15px 0;
  color: #111;
}
.left-text p {
  font-size: 1rem;
  color: #666;
  line-height: 1.5;
  max-width: 320px;
}

/* Signup form */
.signup-form {
  flex: 1;
  background: #fff;
  padding: 30px 40px;
  border-radius: 8px;
  box-shadow: 0 4px 15px rgb(0 0 0 / 0.08);
  display: flex;
  flex-direction: column;
}

.signup-form label {
  margin-top: 15px;
  font-weight: 600;
  font-size: 14px;
}
.signup-form input[type="text"],
.signup-form input[type="email"],
.signup-form input[type="password"] {
  margin-top: 5px;
  padding: 10px 12px;
  font-size: 16px;
  border: 1.5px solid #ccc;
  border-radius: 5px;
  transition: border-color 0.3s ease;
}
.signup-form input[type="text"]:focus,
.signup-form input[type="email"]:focus,
.signup-form input[type="password"]:focus {
  outline: none;
  border-color: #2a5dff;
}

/* Checkbox groups */
.checkbox-group {
  margin-top: 20px;
  font-size: 14px;
  color: #555;
  display: flex;
  align-items: center;
}
.checkbox-group input[type="checkbox"] {
  margin-right: 10px;
  width: 18px;
  height: 18px;
}

/* Submit button */
.signup-form button {
  margin-top: 30px;
  background-color: #2a5dff;
  border: none;
  color: white;
  padding: 14px;
  font-size: 18px;
  font-weight: 700;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}
.signup-form button:hover {
  background-color: #2248cc;
}

/* Below form text */
.below-form {
  margin-top: 20px;
  font-size: 14px;
  color: #444;
}
.below-form a {
  font-weight: 600;
  margin-left: 5px;
}

/* Error message */
.error-message {
  background-color: #ffdddd;
  border: 1px solid #ff5c5c;
  color: #d8000c;
  padding: 10px 15px;
  margin-top: 10px;
  border-radius: 5px;
}

/* Success message */
.success-message {
  background-color: #d4edda;
  border: 1px solid #28a745;
  color: #155724;
  padding: 10px 15px;
  margin-top: 10px;
  border-radius: 5px;
}

/* Responsive */
@media (max-width: 900px) {
  .container {
    flex-direction: column;
    gap: 40px;
    margin: 30px auto;
  }
  .left-text,
  .signup-form {
    flex: unset;
    max-width: 100%;
  }
}

</style>

<!-- Cloudflare Turnstile CAPTCHA script -->
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

</head>
<body>

<!-- Navbar -->
<header class="navbar">
  <div class="logo">CCAM</div>

  <nav class="nav-left">
    <a href="#">Features</a>
    <a href="#">Pricing</a>
    <a href="#">Resources</a>
    <a href="#">About</a>
    <a href="#">Contact</a>
  </nav>

  <div class="nav-right" style="--nav-right-left-offset: -445px;">
    <a href="login.php" class="login-btn">Login</a>
    <a href="login.php" class="get-started-btn">Get Started</a>
  </div>

</header>


<!-- Main container -->
<div class="container">

  <!-- Left Text -->
  <div class="left-text">
    <h1>Sign up to CCAM and meet the ease.</h1>
    <p>CCAM is an online accounting software designed to help small businesses easily keep their finances.</p>
  </div>

  <!-- Signup Form -->
  <form class="signup-form" action="register_process.php" method="POST" novalidate>

    <?php if ($errors): ?>
      <div class="error-message">
        <ul>
          <?php foreach ($errors as $error): ?>
            <li><?=htmlspecialchars($error)?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($success): ?>
      <div class="success-message">
        <?=htmlspecialchars($success)?>
      </div>
    <?php endif; ?>

    <label for="name">Name <span style="color: red">*</span></label>
    <input type="text" id="name" name="name" required placeholder="Your full name" value="<?=htmlspecialchars($old['name'] ?? '')?>" />

    <label for="email">Email <span style="color: red">*</span></label>
    <input type="email" id="email" name="email" required placeholder="you@example.com" value="<?=htmlspecialchars($old['email'] ?? '')?>" />

    <label for="password">Password <span style="color: red">*</span></label>
    <input type="password" id="password" name="password" required placeholder="Choose a strong password" />

    <!-- Cloudflare Turnstile CAPTCHA -->
    <div style="margin-top:20px;">
      <div class="cf-turnstile" data-sitekey="0x4AAAAAABpqMJmfOhFwwYD6"></div>
    </div>

    <div class="checkbox-group" style="margin-top: 15px;">
      <input type="checkbox" id="terms" name="terms" required />
      <label for="terms">I agree to the <a href="#" target="_blank">Terms of Service</a> and <a href="#" target="_blank">Privacy Policy</a></label>
    </div>

    <button type="submit">Create new account</button>

    <div class="below-form">
      Already have an account? <a href="login.php">Login here</a>.
    </div>

  </form>
</div>

</body>
</html>
