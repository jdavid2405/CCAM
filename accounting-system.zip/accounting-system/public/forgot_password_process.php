<?php
session_start();

require __DIR__ . '/../config/db.php'; // $mysqli connection

// Load PHPMailer classes with corrected paths
require __DIR__ . '/../src/PHPMailer.php';
require __DIR__ . '/../src/SMTP.php';
require __DIR__ . '/../src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Invalid email address.";
        header('Location: forgot_password.php');
        exit;
    }

    // Find user by email
    $stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        // Email not found - do NOT reveal this info
        $_SESSION['success'] = "If this email is registered, you will receive a reset link shortly.";
        header('Location: forgot_password.php');
        exit;
    }

    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();

    // Generate token & expiry (1 hour)
    $token = bin2hex(random_bytes(32));
    $expires_at = date('Y-m-d H:i:s', time() + 3600);

    // Store token
    $stmt = $mysqli->prepare('INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)');
    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }
    $stmt->bind_param('iss', $user_id, $token, $expires_at);
    $stmt->execute();
    $stmt->close();

    // Build reset link
    $reset_link = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=$token";

    // Send email with PHPMailer
    $mail = new PHPMailer(true);

    try {
        // SMTP config
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'noreplyccam@gmail.com';         // Your Gmail SMTP email
        $mail->Password   = 'dxlmenfwfsdhffcc';        // Your Gmail app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('noreplyccam@gmail.com', 'CCAM Support');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'CCAM Password Reset Request';
        $mail->Body    = "
            <p>Hello,</p>
            <p>We received a request to reset your password. Click the link below to reset it:</p>
            <p><a href='$reset_link'>$reset_link</a></p>
            <p>This link will expire in 1 hour.</p>
            <p>If you did not request a password reset, please ignore this email.</p>
            <br>
            <p>Thanks,<br>CCAM Team</p>
        ";

        $mail->send();
        $_SESSION['success'] = "If this email is registered, you will receive a reset link shortly.";
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to send email. Please try again later.";
    }

    header('Location: forgot_password.php');
    exit;
} else {
    header('Location: forgot_password.php');
    exit;
}
