<?php
echo password_hash('YourStrongPasswordHere', PASSWORD_DEFAULT);
