<?php
session_start();
require_once __DIR__ . '/../config/db.php'; // This defines constants AND creates $mysqli

$TURNSTILE_SECRET = '0x4AAAAAABpqMEbgCANQD9lJS5OAnu7EeqE';

function verifyTurnstile($token, $secret) {
    $url = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    $data = [
        'secret'   => $secret,
        'response' => $token,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? null
    ];

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($data)
        ]
    ];

    $context = stream_context_create($options);
    $result  = file_get_contents($url, false, $context);

    if ($result === false) {
        return false;
    }

    $resData = json_decode($result, true);
    return $resData['success'] ?? false;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$email    = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']);
$captcha  = $_POST['cf-turnstile-response'] ?? '';

$errors = [];

if (!$email) {
    $errors[] = 'Please enter a valid email address.';
}
if (empty($password)) {
    $errors[] = 'Please enter your password.';
}
if (empty($captcha) || !verifyTurnstile($captcha, $TURNSTILE_SECRET)) {
    $errors[] = 'CAPTCHA verification failed. Please try again.';
}

if ($errors) {
    $_SESSION['login_errors'] = $errors;
    $_SESSION['login_email'] = $email;
    header('Location: login.php');
    exit;
}

// Use $mysqli from config/db.php (already connected)
if ($mysqli->connect_errno) {
    die('Database connection failed: ' . $mysqli->connect_error);
}

$stmt = $mysqli->prepare('SELECT id, name, email, password FROM users WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $errors[] = 'Invalid email or password.';
} else {
    $user = $result->fetch_assoc();
    if (!password_verify($password, $user['password'])) {
        $errors[] = 'Invalid email or password.';
    }
}

$stmt->close();
// Do NOT close $mysqli here since it’s from config.php

if ($errors) {
    $_SESSION['login_errors'] = $errors;
    $_SESSION['login_email'] = $email;
    header('Location: login.php');
    exit;
}

session_regenerate_id(true);
$_SESSION['user'] = [
    'id'    => $user['id'],
    'name'  => $user['name'],
    'email' => $user['email']
];

unset($_SESSION['login_email']);

if ($remember) {
    setcookie(
        'remember_me',
        $user['id'],
        [
            'expires'  => time() + (86400 * 30),
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Strict'
        ]
    );
}

header('Location: dashboard.php');
exit;
