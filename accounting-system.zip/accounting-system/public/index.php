<?php
// public/index.php - login
session_start();
if(isset($_SESSION['user'])){
    header('Location: dashboard.php'); exit;
}
$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    require __DIR__ . '/../config/db.php';
    $email = $_POST['email'] ?? '';
    $pass = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if($user && password_verify($pass, $user['password'])){
        // set session
        $_SESSION['user'] = ['id'=>$user['id'],'full_name'=>$user['full_name'],'email'=>$user['email'],'role'=>$user['role']];
        header('Location: dashboard.php'); exit;
    } else {
        $message = 'Invalid credentials';
    }
}
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row justify-content-center">
  <div class="col-md-4">
    <h3>Login</h3>
    <?php if($message): ?><div class="alert alert-danger"><?php echo htmlspecialchars($message);?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input class="form-control" type="email" name="email" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input class="form-control" type="password" name="password" required>
      </div>
      <button class="btn btn-primary">Login</button>
      <a class="btn btn-link" href="register.php">Register</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
