<?php
session_start();
require_once __DIR__ . '/../config/db.php'; // adjust path if needed

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user']['id'];
$username = $_SESSION['user']['name'] ?? 'User';

// Fetch companies for this user
$stmt = $mysqli->prepare("SELECT id, company_name FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Your Companies</title>
<style>
  body { font-family: Arial, sans-serif; background: #f7f9fc; padding: 40px; }
  .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
  h1 { color: #333; }
  ul { list-style-type: none; padding: 0; }
  li { margin-bottom: 15px; }
  a { text-decoration: none; color: #2a5dff; font-weight: bold; }
  a:hover { text-decoration: underline; }
  .no-companies { color: #888; font-style: italic; }
</style>
</head>
<body>
  <div class="container">
    <h1>Hello, <?= htmlspecialchars($username) ?>! Here are your companies:</h1>
    <?php if ($result->num_rows > 0): ?>
      <ul>
        <?php while ($company = $result->fetch_assoc()): ?>
          <li>
            <a href="step2.php?company_id=<?= $company['id'] ?>">
              <?= htmlspecialchars($company['company_name']) ?>
            </a>
          </li>
        <?php endwhile; ?>
      </ul>
    <?php else: ?>
      <p class="no-companies">You have no companies yet. Please create one.</p>
    <?php endif; ?>
  </div>
</body>
</html>
<?php
$stmt->close();
$mysqli->close();
?>
