<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Login | CCAM</title>
<style>
  /* Reset and base */
  * {
    box-sizing: border-box;
  }
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background: #f9fafb;
    color: #333;
  }
  a {
    color: #2a5dff;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  /* Navbar */
  .navbar {
    display: flex;
    align-items: center;
    background-color: #fff;
    padding: 15px 30px;
    box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
  }
  .navbar .logo {
    margin-right: auto;
    font-weight: 700;
    font-size: 32px;
    color: #2a5dff;
    cursor: pointer;
    margin-left: 443px;
  }
  .nav-left {
    display: flex;
    gap: 30px;
    margin-right: 540px;
  }
  .nav-left a {
    font-weight: 600;
    font-size: 16px;
    color: #545557ff;
    text-decoration: none;
  }
  .nav-left a:hover {
    text-decoration: underline;
  }
  .nav-right {
    display: flex;
    gap: 15px;
    position: relative;
    left: var(--nav-right-left-offset, 0);
  }
  .nav-right button {
    font-weight: 600;
    font-size: 16px;
    padding: 8px 18px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    user-select: none;
    transition: background-color 0.3s ease;
  }
  .login-btn {
    background: transparent;
    color: #2a5dff;
    border: 2px solid #2a5dff;
  }
  .login-btn:hover {
    background: #2a5dff;
    color: white;
  }
  .get-started-btn {
    background: #2a5dff;
    color: white;
  }
  .get-started-btn:hover {
    background: #2248cc;
  }
  /* Main container */
  .container {
    display: flex;
    justify-content: space-between;
    max-width: 1000px;
    margin: 50px auto;
    padding: 0 20px;
    gap: 60px;
  }
  .left-text {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .left-text h1 {
    font-size: 2.5rem;
    font-weight: 900;
    margin: 0 0 15px 0;
    color: #111;
  }
  .left-text p {
    font-size: 1rem;
    color: #666;
    line-height: 1.5;
    max-width: 320px;
  }
  .login-form {
    flex: 1;
    background: #fff;
    padding: 30px 40px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgb(0 0 0 / 0.08);
    display: flex;
    flex-direction: column;
    max-width: 380px;
  }
  .login-form h1 {
    margin: 0 0 15px 0;
    font-weight: 900;
    font-size: 2rem;
    color: #111;
    text-align: center;
  }
  .login-form label {
    margin-top: 15px;
    font-weight: 600;
    font-size: 14px;
    color: #444;
  }
  .login-form input[type="email"],
  .login-form input[type="password"] {
    margin-top: 5px;
    padding: 10px 12px;
    font-size: 16px;
    border: 1.5px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease;
  }
  .login-form input[type="email"]:focus,
  .login-form input[type="password"]:focus {
    outline: none;
    border-color: #2a5dff;
  }
  .checkbox-group {
    margin-top: 20px;
    font-size: 14px;
    color: #555;
    display: flex;
    align-items: center;
  }
  .checkbox-group input[type="checkbox"] {
    margin-right: 10px;
    width: 18px;
    height: 18px;
  }
  button[type="submit"] {
    margin-top: 30px;
    background-color: #2a5dff;
    border: none;
    color: white;
    padding: 14px;
    font-size: 18px;
    font-weight: 700;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button[type="submit"]:hover {
    background-color: #2248cc;
  }
  .links-row {
    margin-top: 20px;
    font-size: 14px;
    color: #444;
    display: flex;
    justify-content: space-between;
  }
  .links-row a {
    font-weight: 600;
  }
  .error-list {
    background-color: #ffdddd;
    border: 1px solid #ff5c5c;
    color: #d8000c;
    padding: 10px 15px;
    margin-top: 10px;
    border-radius: 5px;
  }
  /* Responsive */
  @media (max-width: 900px) {
    .container {
      flex-direction: column;
      gap: 40px;
      margin: 30px auto;
    }
    .left-text,
    .login-form {
      flex: unset;
      max-width: 100%;
    }
  }
</style>
<!-- Cloudflare Turnstile CAPTCHA script -->
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
</head>
<body>

<!-- Navbar -->
<header class="navbar">
  <div class="logo">CCAM</div>

  <nav class="nav-left">
    <a href="#">Features</a>
    <a href="#">Pricing</a>
    <a href="#">Resources</a>
    <a href="#">About</a>
    <a href="#">Contact</a>
  </nav>

  <div class="nav-right" style="--nav-right-left-offset: -445px;">
    <button class="login-btn">Login</button>
    <button class="get-started-btn">Get Started</button>
  </div>
</header>

<!-- Main container -->
<div class="container">
  <!-- Left Text -->
  <div class="left-text">
    <h1>Login to CCAM <br> meet the ease.</h1>
    <p>Access your accounting dashboard and keep your finances organized effortlessly.</p>
  </div>

  <!-- Login Form -->
  <form class="login-form" action="login_process.php" method="POST" novalidate>
    <?php if (!empty($_SESSION['success'])): ?>
      <div style="background-color:#d4edda; color:#155724; border:1px solid #c3e6cb; padding:10px 15px; margin-bottom:15px; border-radius:5px;">
        <?= htmlspecialchars($_SESSION['success']) ?>
      </div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['login_errors'])): ?>
      <div class="error-list">
        <ul>
          <?php foreach ($_SESSION['login_errors'] as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php unset($_SESSION['login_errors']); ?>
    <?php endif; ?>

    <label for="email">Email <span style="color:#dc2626">*</span></label>
    <input
      type="email"
      id="email"
      name="email"
      placeholder="you@example.com"
      required
      value="<?= htmlspecialchars($_SESSION['login_email'] ?? '') ?>"
    />

    <label for="password">Password <span style="color:#dc2626">*</span></label>
    <input
      type="password"
      id="password"
      name="password"
      placeholder="********"
      required
      minlength="6"
    />

    <!-- Cloudflare Turnstile CAPTCHA -->
    <div style="margin-top:20px;">
      <div class="cf-turnstile" data-sitekey="0x4AAAAAABpqMJmfOhFwwYD6"></div>
    </div>

    <div class="checkbox-group" style="margin-top: 15px;">
      <input type="checkbox" id="remember" name="remember" />
      <label for="remember">Remember me</label>
    </div>

    <button type="submit">Login</button>

    <div class="links-row">
      <a href="forgot_password.php">Forgot password?</a>
      <a href="signup.php">Create new account</a>
    </div>
  </form>
</div>

</body>
</html>
