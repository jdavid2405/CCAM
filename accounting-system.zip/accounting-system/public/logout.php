<?php
session_start();

// Clear session data
$_SESSION = [];
session_destroy();

// Clear remember me cookie
setcookie('remember_me', '', time() - 3600, "/");

header('Location: login.php');
exit;
