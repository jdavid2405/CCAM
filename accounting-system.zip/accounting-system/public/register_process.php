<?php
session_start();

// Your DB connection settings here
$host = 'localhost';
$user = 'root';
$pass = ''; // change as needed
$dbname = 'accounting_db';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

// Helper function to verify Cloudflare Turnstile response
function verifyTurnstile($token) {
    $secret = '0x4AAAAAABpqMEbgCANQD9lJS5OAnu7EeqE'; // replace with your secret key
    $response = file_get_contents("https://challenges.cloudflare.com/turnstile/v0/siteverify", false, stream_context_create([
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query([
                'secret' => $secret,
                'response' => $token
            ]),
        ]
    ]));
    $result = json_decode($response, true);
    return $result['success'] ?? false;
}

// Collect and sanitize input
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$terms = isset($_POST['terms']);
$turnstile_token = $_POST['cf-turnstile-response'] ?? '';

$errors = [];
$old = ['name' => $name, 'email' => $email];

// Validate inputs
if (empty($name)) {
    $errors[] = "Name is required.";
}
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Valid email is required.";
}
if (empty($password) || strlen($password) < 6) {
    $errors[] = "Password is required and must be at least 6 characters.";
}
if (!$terms) {
    $errors[] = "You must agree to the Terms of Service and Privacy Policy.";
}
if (empty($turnstile_token) || !verifyTurnstile($turnstile_token)) {
    $errors[] = "CAPTCHA verification failed. Please try again.";
}

// Check if email already exists
if (!$errors) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "Email is already registered.";
    }
    $stmt->close();
}

if ($errors) {
    $_SESSION['errors'] = $errors;
    $_SESSION['old'] = $old;
    header("Location: signup.php");
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed_password);
if ($stmt->execute()) {
    $_SESSION['success'] = "Account created successfully! You can now log in.";
    header("Location: signup.php");
    exit;
} else {
    $_SESSION['errors'] = ["Database error: " . $stmt->error];
    $_SESSION['old'] = $old;
    header("Location: signup.php");
    exit;
}
