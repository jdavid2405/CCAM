<?php
session_start();
require __DIR__ . '/../config/db.php'; // $mysqli connection

// Check POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: reset_password.php');
    exit;
}

// Get and sanitize inputs
$token = $_POST['token'] ?? '';
$password = $_POST['password'] ?? '';
$password_confirm = $_POST['password_confirm'] ?? '';

// Basic validations
if (empty($token)) {
    $_SESSION['error'] = "Invalid or missing token.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}

if (empty($password) || empty($password_confirm)) {
    $_SESSION['error'] = "Please fill in all required fields.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}

if ($password !== $password_confirm) {
    $_SESSION['error'] = "Passwords do not match.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}

if (strlen($password) < 8) {
    $_SESSION['error'] = "Password must be at least 8 characters.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}

// Find the reset request, check expiry
$stmt = $mysqli->prepare('SELECT user_id, expires_at FROM password_resets WHERE token = ? LIMIT 1');
if (!$stmt) {
    error_log("Prepare failed: " . $mysqli->error);
    $_SESSION['error'] = "Internal error. Please try again later.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}
$stmt->bind_param('s', $token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    $_SESSION['error'] = "Invalid or expired reset token.";
    header("Location: reset_password.php");
    exit;
}

$stmt->bind_result($user_id, $expires_at);
$stmt->fetch();
$stmt->close();

if (strtotime($expires_at) < time()) {
    $_SESSION['error'] = "Reset token has expired. Please request a new one.";
    header("Location: reset_password.php");
    exit;
}

// Hash the new password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Update user's password
$stmt = $mysqli->prepare('UPDATE users SET password = ? WHERE id = ?');
if (!$stmt) {
    error_log("Prepare failed: " . $mysqli->error);
    $_SESSION['error'] = "Internal error. Please try again later.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}
$stmt->bind_param('si', $hashed_password, $user_id);
if (!$stmt->execute()) {
    error_log("Failed to update password for user_id: $user_id. Error: " . $stmt->error);
    $_SESSION['error'] = "Failed to update password. Please try again.";
    header("Location: reset_password.php?token=" . urlencode($token));
    exit;
}
$stmt->close();

// Delete the token after successful reset
$stmt = $mysqli->prepare('DELETE FROM password_resets WHERE token = ?');
$stmt->bind_param('s', $token);
$stmt->execute();
$stmt->close();

// Set success message for login page
$_SESSION['success'] = "Your password has been reset successfully! You can now log in.";

// Redirect to login page with success message
header("Location: login.php");
exit;
