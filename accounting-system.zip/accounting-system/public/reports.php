<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: index.php'); exit; }
require __DIR__ . '/../config/db.php';
$user = $_SESSION['user'];
$company_id = null;
$stmt = $pdo->prepare('SELECT id FROM companies WHERE user_id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$company_id = $stmt->fetchColumn();
if(!$company_id){ header('Location: companies.php'); exit; }
$where = 'company_id = ?';
$params = [$company_id];
$start = $_GET['start'] ?? null;
$end = $_GET['end'] ?? null;
if($start){ $where .= ' AND date >= ?'; $params[] = $start; }
if($end){ $where .= ' AND date <= ?'; $params[] = $end; }
$sth = $pdo->prepare("SELECT * FROM transactions WHERE $where ORDER BY date DESC");
$sth->execute($params);
$rows = $sth->fetchAll();

if(isset($_GET['export']) && $_GET['export']=='csv'){
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="transactions.csv"');
    $out = fopen('php://output','w');
    fputcsv($out, ['Date','Type','Category','Amount','Description']);
    foreach($rows as $r){
        fputcsv($out, [$r['date'],$r['type'],$r['category_id'],$r['amount'],$r['description']]);
    }
    fclose($out); exit;
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="row">
  <div class="col-md-8">
    <h4>Reports</h4>
    <form class="row mb-3">
      <div class="col"><input class="form-control" type="date" name="start" value="<?php echo htmlspecialchars($start);?>"></div>
      <div class="col"><input class="form-control" type="date" name="end" value="<?php echo htmlspecialchars($end);?>"></div>
      <div class="col"><button class="btn btn-primary">Filter</button> <a class="btn btn-outline-secondary" href="?export=csv">Export CSV</a></div>
    </form>
    <table class="table table-sm">
      <thead><tr><th>Date</th><th>Type</th><th>Category</th><th>Amount</th><th>Description</th></tr></thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr><td><?php echo htmlspecialchars($r['date']);?></td><td><?php echo htmlspecialchars($r['type']);?></td><td><?php echo htmlspecialchars($r['category_id']);?></td><td><?php echo number_format($r['amount'],2);?></td><td><?php echo htmlspecialchars($r['description']);?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
