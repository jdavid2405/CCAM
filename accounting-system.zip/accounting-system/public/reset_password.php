<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Reset Password | CCAM</title>
<style>
  /* Your existing CSS remains unchanged */
  * {
    box-sizing: border-box;
  }
  body {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background: #f9fafb;
    color: #333;
  }
  a {
    color: #2a5dff;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  /* Navbar */
  .navbar {
    display: flex;
    align-items: center;
    background-color: #fff;
    padding: 15px 30px;
    box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
  }
  .navbar .logo {
    margin-right: auto;
    font-weight: 700;
    font-size: 32px;
    color: #2a5dff;
    cursor: pointer;
    margin-left: 369px;
  }
  .nav-left {
    display: flex;
    gap: 30px;
    margin-right: 540px;
  }
  .nav-left a {
    font-weight: 600;
    font-size: 16px;
    color: #545557ff;
    text-decoration: none;
  }
  .nav-left a:hover {
    text-decoration: underline;
  }
  .nav-right {
    display: flex;
    gap: 15px;
    position: relative;
    left: var(--nav-right-left-offset, 0);
  }
  /* Style nav-right links as buttons */
  .nav-right a {
    font-weight: 600;
    font-size: 16px;
    padding: 8px 18px;
    border-radius: 6px;
    cursor: pointer;
    user-select: none;
    transition: background-color 0.3s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    border: none;
  }
  .login-btn {
    background: transparent;
    color: #2a5dff;
    border: 2px solid #2a5dff;
  }
  .login-btn:hover {
    background: #2a5dff;
    color: white;
  }
  .get-started-btn {
    background: #2a5dff;
    color: white;
  }
  .get-started-btn:hover {
    background: #2248cc;
  }
  /* Main container */
  main {
    max-width: 900px;
    margin: 40px auto;
    padding: 0 20px;
  }
  /* Left-block styling */
  .left-block {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    gap: 1.5rem;
    padding-top: 50px;
    margin-left: -125px;
  }
  /* Reset Password Title */
  .reset-title {
    font-size: 4rem;
    font-weight: 650;
    color: #111;
    margin: 0 0 40px 0;
    user-select: none;
  }
  /* Form wrapper */
  .form-wrapper {
    max-width: 420px;
    margin: 0 auto;
    text-align: center;
    width: 100%;
  }
  form {
    display: flex;
    flex-direction: column;
    gap: 1.2rem;
    width: 100%;
  }
  label {
    font-size: 0.9rem;
    font-weight: 600;
    color: #444;
    text-align: left;
    display: block;
  }
  input[type="password"] {
    padding: 10px 12px;
    font-size: 16px;
    border: 1.5px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease;
    width: 650px;
    max-width: 100%;
    background: transparent;
  }
  input[type="password"]:focus {
    outline: none;
    border-color: #2a5dff;
  }
  button[type="submit"] {
    margin-top: 30px;
    background-color: #2a5dff;
    border: none;
    color: white;
    padding: 14px;
    font-size: 18px;
    font-weight: 700;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    user-select: none;
    width: 650px;
    max-width: 100%;
  }
  button[type="submit"]:hover {
    background-color: #2248cc;
  }
  /* Responsive */
  @media (max-width: 900px) {
    main {
      margin: 30px 15px;
    }
    .left-block {
      margin-left: 0;
      align-items: stretch;
    }
    input[type="password"],
    button[type="submit"] {
      width: 100%;
    }
  }
</style>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
</head>
<body>

<!-- Navbar -->
<header class="navbar">
  <div class="logo">CCAM</div>

  <nav class="nav-left">
    <a href="#">Features</a>
    <a href="#">Pricing</a>
    <a href="#">Resources</a>
    <a href="#">About</a>
    <a href="#">Contact</a>
  </nav>

  <div class="nav-right" style="--nav-right-left-offset: -445px;">
    <a href="login.php" class="login-btn">Login</a>
    <a href="login.php" class="get-started-btn">Get Started</a>
  </div>
</header>

<main>
  <section class="left-block">
    <h1 class="reset-title">Reset Password</h1>

    <?php if (!empty($_SESSION['error'])): ?>
      <div style="background-color:#f8d7da; color:#842029; border:1px solid #f5c2c7; padding:10px; border-radius:5px; margin-bottom:15px;">
        <?= htmlspecialchars($_SESSION['error']) ?>
      </div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form action="reset_password_process.php" method="POST" novalidate>
      <input type="hidden" name="token" value="<?= htmlspecialchars($_GET['token'] ?? '') ?>" />

      <label for="password">New Password <span style="color:#dc2626">*</span></label>
      <input
        type="password"
        id="password"
        name="password"
        placeholder="Enter new password"
        required
        autocomplete="new-password"
      />

      <label for="password_confirm">Confirm Password <span style="color:#dc2626">*</span></label>
      <input
        type="password"
        id="password_confirm"
        name="password_confirm"
        placeholder="Confirm new password"
        required
        autocomplete="new-password"
      />

      <!-- Cloudflare Turnstile CAPTCHA -->
      <div style="margin-top:20px;">
        <div class="cf-turnstile" data-sitekey="0x4AAAAAABpqMJmfOhFwwYD6"></div>
      </div>

      <button type="submit">Reset Password</button>
    </form>
  </section>
</main>

</body>
</html>
