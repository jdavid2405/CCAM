# Accounting System (Base)
Drop this folder into `C:\xampp\htdocs\accounting-system`.

## Quick setup
1. Start XAMPP Apache & MySQL.
2. Create a database named `gcam_system` (or edit config/config.sample.php -> db.name).
3. Import `sql/accounting_schema.sql` using phpMyAdmin.
4. Copy `config/config.sample.php` to `config/config.php` and set DB credentials + SMTP/Twilio if needed.
5. Open in browser: http://localhost/accounting-system/public/ (or use the public folder directly)
6. Login with seeded admin:
   - Email: admin@local.test
   - Password: Admin12345!

## Notes
- This is a base skeleton made for your team to expand. It includes auth, company creation placeholders, dashboard, transactions, and categories pages.
- Email/SMS verification code uses placeholders — add SMTP/Twilio keys in config.php to enable.
