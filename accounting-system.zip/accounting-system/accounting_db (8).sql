-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2025 at 05:17 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accounting_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_info`
--

CREATE TABLE `business_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `business_currency` varchar(10) NOT NULL,
  `company_country` varchar(100) NOT NULL,
  `business_email` varchar(255) DEFAULT NULL,
  `business_start_date` date DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dashboard_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `business_info`
--

INSERT INTO `business_info` (`id`, `user_id`, `company_name`, `business_currency`, `company_country`, `business_email`, `business_start_date`, `contact_number`, `address`, `created_at`, `updated_at`, `dashboard_file`) VALUES
(8, 4, 'Sulasok', 'PHP', 'Philippines', NULL, NULL, NULL, NULL, '2025-08-10 11:24:04', '2025-08-10 11:24:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `tax_number` varchar(255) DEFAULT NULL,
  `financial_year_start` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `business_currency` varchar(10) NOT NULL DEFAULT 'PHP',
  `company_country` varchar(100) NOT NULL DEFAULT 'Philippines'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `user_id`, `tax_number`, `financial_year_start`, `address`, `country`, `company_name`, `created_at`, `updated_at`, `business_currency`, `company_country`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 'longwee', '2025-08-09 04:26:06', '2025-08-09 04:26:06', 'PHP', 'Philippines'),
(29, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:05:15', '2025-08-12 02:05:15', 'PHP', 'Philippines'),
(31, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:07:28', '2025-08-12 02:07:28', 'PHP', 'Philippines'),
(32, 3, NULL, NULL, NULL, NULL, 'benji labas utong', '2025-08-12 02:22:35', '2025-08-12 02:22:35', 'PHP', 'Belize'),
(33, 3, '', '0000-00-00', '', '', '', '2025-08-12 02:22:41', '2025-08-12 02:22:41', 'PHP', 'Philippines'),
(34, 3, NULL, NULL, NULL, NULL, 'bayabas', '2025-08-12 03:16:46', '2025-08-12 03:16:46', 'PHP', 'Benin'),
(35, 3, '9999999999', '2025-07-30', 'asd', 'Belarus', '', '2025-08-12 03:16:55', '2025-08-12 03:16:55', 'PHP', 'Philippines');

-- --------------------------------------------------------

--
-- Table structure for table `company_profiles`
--

CREATE TABLE `company_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_do` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `business_length` varchar(255) NOT NULL,
  `team_size` varchar(255) NOT NULL,
  `billing` varchar(255) NOT NULL,
  `akaunting` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_profiles`
--

INSERT INTO `company_profiles` (`id`, `company_id`, `company_do`, `role`, `business_length`, `team_size`, `billing`, `akaunting`, `created_at`, `updated_at`) VALUES
(12, 29, '', '', '', '', '', '[]', '2025-08-12 02:05:16', '2025-08-12 02:05:16'),
(13, 31, '', '', '', '', '', '[]', '2025-08-12 02:07:29', '2025-08-12 02:07:29'),
(14, 33, '', '', '', '', '', '[]', '2025-08-12 02:22:42', '2025-08-12 02:22:42'),
(15, 35, '', 'CEO/CFO/COO', '', '', '', '[]', '2025-08-12 03:16:57', '2025-08-12 03:16:57');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token`, `expires_at`, `created_at`) VALUES
(2, 1, 'f3e9f32bc2c31afd1b8fbc3a97cfe359f78c97abfc691d1c6dfca22ad9e2f911', '2025-08-08 22:34:29', '2025-08-08 19:34:29'),
(4, 4, 'f0cbdbb9d6228c63cdc8c6a6fda7e20eeb9bf75ee8e4accc4c38be3241709c83', '2025-08-10 14:21:54', '2025-08-10 11:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'PUTO', 'enjiqt@gmail.com', '$2y$10$zXyawCv.m3Yt/bday7tkuOg.iN3fLzsTI9CCbabgOymuc7g9qcZ3e', '2025-08-08 15:37:40', '2025-08-08 19:44:00'),
(2, 'KUTSINTA', 'ariana@gmail.com', '$2y$10$Azz82c8UkuwVuitZCY5WKeF33JjeUc7Qc3nh1s8V0.T9sYFDRKxiq', '2025-08-08 17:39:24', '2025-08-08 17:39:24'),
(3, 'Geero Andrei', 'jhonmichaelsabado123@gmail.com', '$2y$10$quzi9.A/D6tHDXuJxj6kPuGzHNnNEtuuESyZRxGsiOltAr1XCcnt2', '2025-08-09 04:32:19', '2025-08-09 04:32:19'),
(4, 'Aldrich Mico Felizardo', 'aldrichmico.29@gmail.com', '$2y$10$BrvarIvqq4TuT1CiqKM3tOFB69ytmWhnLmI90s27KSolw8LgZhD.2', '2025-08-10 11:21:21', '2025-08-10 11:21:21');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `widget_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `width` varchar(10) NOT NULL DEFAULT '50%',
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`widget_id`, `user_id`, `company_id`, `name`, `type`, `width`, `sort_order`, `created_at`, `updated_at`) VALUES
(6, 4, 8, 'KUTSINTA', 'Receivables', '50%', 1, '2025-08-10 11:25:46', '2025-08-11 11:57:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_info`
--
ALTER TABLE `business_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_id` (`company_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`widget_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_widgets_company` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_info`
--
ALTER TABLE `business_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `company_profiles`
--
ALTER TABLE `company_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `widget_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `business_info`
--
ALTER TABLE `business_info`
  ADD CONSTRAINT `business_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `company_profiles`
--
ALTER TABLE `company_profiles`
  ADD CONSTRAINT `company_profiles_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `widgets`
--
ALTER TABLE `widgets`
  ADD CONSTRAINT `fk_widgets_company` FOREIGN KEY (`company_id`) REFERENCES `business_info` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `widgets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
